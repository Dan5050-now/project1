/* ============================================================ 10. tables */

/** Month labels with the year shown where it changes, plus a divider at each year
 *  boundary. Repeating the year under all 24 columns is noise; showing it only at the
 *  first column and each January is the smallest mark that answers "which year is this".
 *  One helper so the three time charts label their axes identically. */
function monthAxis(o, G, xOf, bw, yLabel, yTick, yDiv0, yDiv1){
  G.forEach((k, i) => {
    const [mon, yr] = keyToLabel(k).split(" ");
    const cx = xOf(i) + bw / 2;
    o.push(`<text class="ax" x="${cx.toFixed(1)}" y="${yLabel}" text-anchor="middle">${mon}</text>`);
    if (i === 0 || k % 12 === 0){
      o.push(`<text class="ax yr" x="${cx.toFixed(1)}" y="${yTick}" text-anchor="middle">${yr}</text>`);
      if (i > 0){
        const dx = xOf(i) - (bw * 0.06);
        o.push(`<line class="yrdiv" x1="${dx.toFixed(1)}" y1="${yDiv0}" x2="${dx.toFixed(1)}" y2="${yDiv1}"/>`);
      }
    }
  });
}

function monthHead(){
  return grid().map(k => {
    const [mon, yr] = keyToLabel(k).split(" ");
    const tip = `<b>${keyToLabel(k)}</b><br>Each cell is that month's load in ${unitLabel()}: `
      + `period weight × role factor × person weight × the fraction of the month covered. `
      + `A partial month is prorated by calendar days.`;
    return `<th data-tip="${att(tip)}">${mon}<br><span class="sub">${yr}</span></th>`;
  }).join("");
}

/* ---------------------------------------------- how a project's figures were made (R-56)

   Resource by project drew every figure the same way, whether the assumptions produced
   it or somebody typed it - and those are different claims. A stated figure is a
   judgement about this study; an automatic one is what a study of its kind usually
   takes. Reading the table without knowing which is which, a reader cannot tell a
   project that is genuinely light from one somebody has written down as light. */

/** 'manual' (the project's month is stated), 'mixed' (some of its assignments are),
 *  or 'auto'; and how many assignments are stated. */
function estimationOf(pid){
  const M = S.model;
  if (M.isManual && M.isManual("project", pid)) return {kind:"manual", n:0};
  const n = M.assignments.filter(a => a.project_id === pid
                                   && M.isManual && M.isManual("assignment", a.assignment_id)).length;
  return {kind: n ? "mixed" : "auto", n};
}

function estimationPill(pid){
  const e = estimationOf(pid);
  const [label, tip] = e.kind === "manual"
    ? ["Manual", "<b>Manual estimation</b><br>This project's monthly total is STATED on "
       + "MonthlyEstimate rather than worked out from the standard. The people on it are "
       + "scaled so they add up to the stated figure, and a month can sit above or below "
       + "what the standard would say — that is what Standard vs staffed reports."]
    : e.kind === "mixed"
    ? [`Auto · ${e.n} manual`, `<b>Partly stated</b><br>The project is calculated from the `
       + `standard, but ${e.n} of its assignment(s) carry a figure stated by hand. Those `
       + `people's months are what was typed; everyone else divides the rest.`]
    : ["Auto", "<b>Automatic estimation</b><br>Every figure on this row is worked out from "
       + "the assumptions: standard FTE × period weight × the part of the month it runs, "
       + "shared among the people on it."];
  return `<span class="estb ${e.kind}" data-tip="${att(tip)}">${label}</span>`;
}

/** Project-months whose figure includes anything stated by hand, as "pid|k". */
function manualMonths(){
  const out = new Set();
  for (const L of (S.calc.lines || []))
    if (L.manual_assignment || L.manual_project) out.add(L.project_id + "|" + L.month);
  return out;
}

/* ----------------------------------------------- narrowing the table to its problems (R-56)

   A portfolio of sixty projects with four in trouble is a table of fifty-six rows to
   scroll past. The control narrows the ROWS to the projects with a problem IN THE MONTHS
   ON SCREEN; it does not touch the control beside it or the tiles, which go on counting
   everything, for the reason R-53 gives: an alarm that followed somebody's view would be
   an alarm that lies. */
const PROJ_ISSUES = [
  ["", "All projects"],
  ["issues", "Issues only (short, over, not staffed)"],
  ["short", "\u25BC Short of standard"],
  ["over", "\u25B2 Over standard"],
  ["unstaffed", "\u25E6 Not staffed"],
  ["manual", "\u270E Stated by hand"],
];

function projIssues(pid, G, man){
  const C = S.calc, out = new Set();
  for (const k of G){
    const g = gapOf(pid, k);
    if (g) out.add(g.dir);
    if ((C.projUnallocated.get(pid + "|" + k) || 0) > 0.004) out.add("unstaffed");
    if (man.has(pid + "|" + k)) out.add("manual");
  }
  return out;
}

function projIssueControl(){
  return `<label class="ctl projissue"><span>Show</span><select id="projIssue">`
    + PROJ_ISSUES.map(([v, l]) => `<option value="${v}"${S.projIssue === v ? " selected" : ""}>`
      + `${esc(l)}</option>`).join("")
    + `</select></label>`;
}

function tableProjects(pids){
  const M = S.model, C = S.calc, G = grid();
  const man = manualMonths();
  const f = S.projIssue || "";
  const listed = pids.slice().sort(byRank).filter(pid => {
    if (!f) return true;
    const has = projIssues(pid, G, man);
    return f === "issues" ? has.has("short") || has.has("over") || has.has("unstaffed")
                          : has.has(f);
  });
  if (f && !listed.length)
    return `<p class="note">None of the ${pids.length} project(s) in view has
      ${esc((PROJ_ISSUES.find(x => x[0] === f) || ["", f])[1].toLowerCase())} in these
      months. <strong>Show: All projects</strong> brings the full table back.</p>`;
  let vmax = 0;
  for (const p of listed) for (const k of G) vmax = Math.max(vmax, C.projMonth.get(p+"|"+k) || 0);
  const body = [];
  for (const pid of listed){
    const open = S.expanded.has("p-"+pid);
    let tot = 0;
    const tds = G.map(k => {
      const v = C.projMonth.get(pid+"|"+k) || 0; tot += v;
      /* A month that is not what the project's own standard asks for is marked HERE,
         on the figure, rather than only in a pop-up or a panel (V-34). A shortfall you
         have to hover to discover is very nearly as silent as one nobody reports: the
         whole failure being fixed is that the application quietly drew a smaller
         project. Both directions are marked and they are marked DIFFERENTLY - short of
         the standard and over it are different facts. */
      const g = gapOf(pid, k);
      const hand = man.has(pid + "|" + k);
      const handLine = `<span class="tr">&#9998; includes a figure stated by hand `
        + `(manual estimation)</span><br>`;
      const mark = (g ? ` gapc ${g.dir}` : "") + (hand ? " man" : "");
      const gtip = g ? ` data-gap="${att(pid)}" data-gk="${k}"`
        + ` data-tip="${att(`<b>${keyToLabel(k)}</b><br>${gapLine(pid, k)}`
        + (hand ? handLine : "")
        + `<span class="tr">click for the month and the figures behind it</span>`)}"`
        : hand ? ` data-tip="${att(`<b>${keyToLabel(k)}</b><br>${handLine}`
        + `<span class="tr">on its standard: the stated figure matches what it needs</span>`)}"`
        : "";
      if (v <= 0.004){
        /* WHAT THE MONTH ASKS FOR WHEN NOBODY IS ON IT (R-49). A dot here used to be
           the only thing this table said about a month inside the project's own run
           with no one assigned to it - and a dot reads as "this costs nothing" rather
           than "nobody has been put on this yet". The two are not the same statement
           and the difference is the whole point of the screen.

           DRAWN AS DEMAND, NEVER AS RESOURCE. It carries a glyph as well as a colour
           (D-04), it is never added into the row or column total - those stay the
           APPLIED figure, so this table and the person table still reconcile - and the
           unallocated is totalled on its own line instead. Short and over are never
           netted (V-34) and neither is this. */
        const u = C.projUnallocated.get(pid + "|" + k) || 0;
        if (u > 0.004)
          return `<td class="c unal" data-tip="${att(`<b>${keyToLabel(k)}</b><br>`
            + `<b>${u.toFixed(2)} FTE</b> is what this project's own standard asks for `
            + `in this month, and NOBODY IS ASSIGNED to it.<br>`
            + `It is not counted in any total on this table: the totals are what is `
            + `being applied, and this is not applied to anybody yet.`
            + `<span class="tr">assign somebody and the figure moves into the row`
            + `</span>`)}">&#9702; ${fmt(u)}</td>`;
        return `<td class="c z${mark}"${gtip}>&middot;</td>`;
      }
      const i = seqStep(v, vmax);
      return `<td class="c${mark}"${gtip} style="background:${SEQ[i]};`
        + `color:${i>6?"#fff":"var(--ink)"}">${fmt(v)}</td>`;
    }).join("");
    // The unallocated sum for this row, alongside the applied total and never inside it.
    let utot = 0;
    for (const k of G) utot += C.projUnallocated.get(pid + "|" + k) || 0;
    const usub = utot > 0.004
      ? `<span class="unals" title="What this project's own standard asks for across `
        + `these months with nobody assigned to it. Not included in the total beside `
        + `it.">&#9702; ${fmt(utot)} unstaffed</span>` : "";
    body.push(`<tr class="parent" data-k="p-${esc(pid)}" tabindex="0" role="button" `
      + `aria-expanded="${open}"><th class="rh"><span class="exp">${open?"&#9662;":"&#9656;"}</span>`
      + `<span class="nm">${esc(M.projects[pid].project_name)}</span>${typePill(pid)}${phasePill(pid)}`
      + estimationPill(pid)
      + `<span class="sub">${esc(pid)} &middot; starts ${ymd(M.projects[pid].start_date)}${usub}</span></th>`
      + `${tds}<td>${fmt(tot)}</td></tr>`);
    if (!open) continue;
    const rows = M.assignments.filter(a => a.project_id === pid)
      .sort((a,b) => (a.role_name||"").localeCompare(b.role_name||"") ||
                     (a.person_id||"").localeCompare(b.person_id||""));
    for (const a of rows){
      let dt = 0;
      const dtds = G.map(k => {
        const v = C.cell.get([pid, a.person_id, a.role_name, k].join("|")) || 0; dt += v;
        return v > 0.004 ? `<td class="c">${fmt(v)}</td>` : '<td class="c z">&middot;</td>';
      }).join("");
      if (dt <= 0.004) continue;
      const stated = M.isManual && (M.isManual("assignment", a.assignment_id)
                                    || M.isManual("project", pid));
      body.push(`<tr class="child"><th class="rh">&#8627; `
        + `${esc((M.people[a.person_id]||{}).person_name || a.person_id)}`
        + `<span class="role">${esc(a.role_name)}</span>`
        + (stated ? `<span class="estb manual sm" data-tip="${att(
            M.isManual("assignment", a.assignment_id)
              ? "<b>Stated by hand</b><br>This assignment's months are typed on MonthlyEstimate."
              : "<b>Scaled to a stated total</b><br>The project's month is stated, and this "
                + "person's share is scaled so the people add up to it.")}">manual</span>`
                  : "")
        + `</th>${dtds}<td>${fmt(dt)}</td></tr>`);
    }
  }
  let gt = 0;
  const gtds = G.map(k => {
    let s = 0; for (const p of listed) s += C.projMonth.get(p+"|"+k) || 0; gt += s;
    return `<td>${fmt(s)}</td>`;
  }).join("");
  body.push(`<tr class="grand"><th class="rh">${f ? `${listed.length} of ${pids.length} `
    + `projects shown` : `All ${listed.length} projects`}</th>${gtds}<td>${fmt(gt)}</td></tr>`);
  /* ON ITS OWN LINE, NEVER ADDED TO THE ONE ABOVE. The row above is what is APPLIED,
     and it is the figure that must equal the person table's grand total (spec sheet 06).
     Unallocated demand belongs to no person, so adding it there would break the one
     reconciliation this screen guarantees - and would also assert that the work is being
     done by somebody, which is the opposite of what it says. */
  let ut = 0;
  const utds = G.map(k => {
    let s = 0; for (const p of listed) s += C.projUnallocated.get(p+"|"+k) || 0; ut += s;
    return s > 0.004 ? `<td class="unal">${fmt(s)}</td>` : `<td class="z">&middot;</td>`;
  }).join("");
  if (ut > 0.004)
    body.push(`<tr class="grand unalrow"><th class="rh">&#9702; Not staffed — what the `
      + `standards ask for with nobody on it<span class="sub">not included in the row `
      + `above; it belongs to no person, and the total above is what the person table `
      + `reconciles against</span></th>${utds}<td class="unal">${fmt(ut)}</td></tr>`);
  return `<table class="grid-t"><thead><tr><th class="rh">Project</th>${monthHead()}`
    + `<th>Total</th></tr></thead><tbody>${body.join("")}</tbody></table>`;
}

function tablePeople(sids){
  const M = S.model, C = S.calc, G = grid();
  const listed = sids.slice().sort();
  let vmax = 0;
  for (const s of listed) for (const k of G) vmax = Math.max(vmax, C.persMonth.get(s+"|"+k) || 0);
  const body = [];
  for (const sid of listed){
    const open = S.expanded.has("s-"+sid);
    let tot = 0;
    const tds = G.map(k => {
      const v = C.persMonth.get(sid+"|"+k) || 0; tot += v;
      if (v > M.OVER) return `<td class="c over">&#9650; ${fmt(v)}</td>`;
      if (v > 0 && v < M.UNDER) return `<td class="c under">&#9660; ${fmt(v)}</td>`;
      if (v <= 0.004) return '<td class="c z">&middot;</td>';
      const i = seqStep(v, vmax);
      return `<td class="c" style="background:${SEQ[i]};color:${i>6?"#fff":"var(--ink)"}">${fmt(v)}</td>`;
    }).join("");
    const cap = num((M.people[sid]||{}).capacity_fte);
    body.push(`<tr class="parent" data-k="s-${esc(sid)}" tabindex="0" role="button" `
      + `aria-expanded="${open}"><th class="rh"><span class="exp">${open?"&#9662;":"&#9656;"}</span>`
      + `<span class="nm">${esc((M.people[sid]||{}).person_name || sid)}</span>`
      + `<span class="sub">${esc(sid)}${cap!==null&&cap!==undefined?` &middot; capacity ${cap.toFixed(2)} FTE`:""}`
      + ` &middot; ${esc((M.people[sid]||{}).department || "")}</span></th>${tds}<td>${fmt(tot)}</td></tr>`);
    if (!open) continue;
    const mine = M.assignments.filter(a => a.person_id === sid)
      .sort((a,b) => byRank(a.project_id, b.project_id));
    for (const a of mine){
      let dt = 0;
      const dtds = G.map(k => {
        const v = C.cell.get([a.project_id, sid, a.role_name, k].join("|")) || 0; dt += v;
        return v > 0.004 ? `<td class="c">${fmt(v)}</td>` : '<td class="c z">&middot;</td>';
      }).join("");
      if (dt <= 0.004) continue;
      body.push(`<tr class="child"><th class="rh">&#8627; `
        + `${esc((M.projects[a.project_id]||{}).project_name || a.project_id)}`
        + `${typePill(a.project_id)}${phasePill(a.project_id)}`
        + `<span class="role">${esc(a.role_name)}</span></th>${dtds}<td>${fmt(dt)}</td></tr>`);
    }
  }
  let gt = 0;
  const gtds = G.map(k => {
    let s = 0; for (const p of listed) s += C.persMonth.get(p+"|"+k) || 0; gt += s;
    return `<td>${fmt(s)}</td>`;
  }).join("");
  body.push(`<tr class="grand"><th class="rh">All ${listed.length} people</th>${gtds}<td>${fmt(gt)}</td></tr>`);
  return `<table class="grid-t"><thead><tr><th class="rh">Person</th>${monthHead()}`
    + `<th>Total</th></tr></thead><tbody>${body.join("")}</tbody></table>`;
}

/** Editable data table. Every cell is editable; edits are validated on entry. */
/** Value suggestions for a column: the Lists sheet where the column is backed by one,
 *  otherwise the distinct values already present in that column. The second half is what
 *  covers project_category, department and the rest - columns with no formal list but a
 *  real vocabulary that a typist should not have to remember or re-invent. */
const LIST_FOR = {
  project_type:"project_type", clinical_phase:"clinical_phase",
  work_scope_type:"work_scope_type", status:"project_status",
  EDC_setup:"setup_party", DataReviewSystem_setup:"setup_party",
  RBQM_setup:"setup_party", DM_conduct:"setup_party",
  EDC_system:"EDC_system", DataReviewSystem:"DataReviewSystem", RBQM_system:"RBQM_system",
  milestone_name:"milestone_name", milestone_highlight:"milestone_highlight",
};
/** A column the user TYPES INTO that is not stored on the row it appears in.
 *
 *  On the Assignments table the project is identified by project_id, and 'PRJ-014' is
 *  not what anyone knows a project by. So project_name is the field to fill in, and the
 *  identifier is derived from it: type a name, and project_id follows. Editing
 *  project_id directly still works and the name follows instead - the two are one field
 *  seen from two ends, not a field and a copy of it.
 *
 *  The name is never written onto the Assignment row. The Assignment sheet has no such
 *  column, so a stored copy could not survive an export and re-import, and it would be a
 *  second version of a fact the Project sheet already owns. */
const PROXY = {
  Assignment: {
    project_name: {
      into: "project_id",
      show: r => (S.model.projects[r.project_id] || {}).project_name ?? "",
      options: () => Object.values(S.model.projects)
        .map(p => p.project_name).filter(v => v !== null && v !== undefined && v !== "")
        .map(String).sort(),
      resolve(name){
        const want = String(name).trim().toLowerCase();
        const hits = Object.values(S.model.projects)
          .filter(p => String(p.project_name ?? "").trim().toLowerCase() === want);
        if (hits.length === 1) return {value: hits[0].project_id};
        if (hits.length) return {error: `More than one project is called '${name}'. `
          + `Enter the project_id instead — that is the field that has to be unique.`};
        const near = this.options().filter(o => o.toLowerCase().includes(want)).slice(0, 3);
        return {error: `No project is called '${name}'.`
          + (near.length ? ` Did you mean ${near.map(o => `'${o}'`).join(", ")}?`
                         : ` Add the project on the Source data (project) tab first.`)};
      },
    },
  },
};
const proxyFor = (sheet, col) => (PROXY[sheet] || {})[col];

/** The rows of a child sheet that belong to the selected parent.
 *
 *  A row still being DRAFTED is admitted only while its parent key is empty. The moment
 *  it names a parent it belongs to that parent and to no other. The earlier rule was a
 *  bare `|| r.__new`, added so a new row would be visible before its key was filled in;
 *  because it was unconditional it put a row drafted under one person on EVERY other
 *  person's tab - and on the overrides table, where the project and role columns are
 *  looked up from the assignment, that row then described someone else's work. */
/* A child table is shown filtered to the parent selected above it. A row that carries
   NO parent key belongs to no parent, so no filter would ever show it - and a row that
   cannot be seen cannot be repaired or deleted, only silently dropped on the next round
   trip. It is shown wherever the user is instead, which is the only place they can act
   on it. (Drafts are the common case: a row seeded with its parent covers most of them,
   this covers the rest, and a keyless row that reached the file covers the last.) */
const childrenOf = (rows, col, val) =>
  rows.filter(r => r[col] === val || !r[col]);

/** Sheets whose key is allocated for the user when a row is inserted. An assignment_id
 *  carries no meaning beyond being unique, so making someone invent one is asking them
 *  to do the machine's job - and to do it wrong, since the row is rejected at Save if
 *  the number collides with one already in the file. */
/* Every column of a sheet the user may type into: the schema's own order, minus the
   derived ones. The project and people tables used to show a curated subset, which reads
   more calmly - and means five Project columns have no home anywhere in the application.
   That was survivable while every plan arrived as a workbook someone had filled in
   elsewhere. It is not survivable now that a plan can be BUILT here: a field with no home
   is a field that can never be entered, and V-10 would warn about it forever. */
const entryCols = sheet =>
  SHEET_HEADERS[sheet].filter(c => !(DERIVED_COLS[sheet] || []).includes(c));

const AUTO_KEY = new Set(["Project","Person","Assignment"]);
// Where to start when the sheet is empty and there is no house style to copy - which is
// every sheet, in a plan started blank.
const FIRST_KEY = {Project:["PRJ-", 3], Person:["PSN-", 3], Assignment:["ASG-", 3]};

/** The next identifier in the pattern the sheet already uses: the LARGEST number in it,
 *  plus one.
 *
 *  It used to allocate the smallest UNUSED number, so that a file whose ids ran 1..46 and
 *  then jumped to 901 for a handful of hand-placed rows would not start climbing from
 *  902. That reasoning was about tidiness; running one past the end is about being able
 *  to tell at a glance which rows you added today, and it is what was asked for. A gap
 *  left by a deleted row now stays a gap, which is the ordinary behaviour of an
 *  identifier sequence anywhere else. */
function nextKey(sheet, col){
  if (!col) return null;
  const used = new Set();
  let prefix = null, width = 3;
  for (const r of (S.model.raw[sheet] || [])){
    const v = r[col];
    if (v === null || v === undefined || String(v).trim() === "") continue;
    const m = /^(.*?)(\d+)$/.exec(String(v).trim());
    if (!m) continue;
    if (prefix === null){ prefix = m[1]; width = m[2].length; }
    if (m[1] === prefix) used.add(+m[2]);
  }
  if (prefix === null){
    // Nothing to follow. In a loaded workbook that means the sheet is empty and the
    // house style is unknown, so the user names the row. But in a plan started blank
    // EVERY sheet starts empty, and the first assignment would then be the one row the
    // application refuses to name - having named every one after it. So the sheets that
    // allocate their own keys carry a pattern to start from.
    const p = FIRST_KEY[sheet];
    return p ? p[0] + String(1).padStart(p[1], "0") : null;
  }
  const n = Math.max(0, ...used) + 1;
  // A sequence that has outgrown its width keeps counting rather than truncating.
  return prefix + String(n).padStart(width, "0");
}

/* What a new row starts with, beyond its identifier and its parent key.
 *
 *  Two kinds of value, for two reasons.
 *
 *  A SEQUENCE continues its parent's own numbering, so the row lands at the end of the
 *  list it belongs to rather than at position "blank", which sorts first.
 *
 *  A WEIGHT starts at 1.00, because 1.00 is the neutral multiplier: a period nobody has
 *  weighted yet must not silently scale the load up or down, a person is available for
 *  one full FTE until told otherwise, and someone put on a project is on it fully until
 *  someone says what share. Starting them empty means starting them at ZERO, since an
 *  empty weight reads as 0.00 in the calculation - a row that quietly contributes
 *  nothing is worse than one that contributes too much, because nothing draws the eye. */
const NEW_ROW = {
  Milestone:          {milestone_seq: () => nextSeq("Milestone", "milestone_seq",
                                                    "project_id", S.selProj)},
  // ProjectPeriod has no period_id: the sheet is keyed on (project_id, period_name) and
  // period_seq is what carries the ORDER. So that is the number allocated here, one past
  // the highest in this project, exactly as milestone_seq is.
  ProjectPeriod:      {period_seq: () => nextSeq("ProjectPeriod", "period_seq",
                                                 "project_id", S.selProj),
                       weight: 1.00},
  Person:             {capacity_fte: 1.00},
  Assignment:         {person_weight: 1.00},
  PersonPeriodWeight: {weight_override: 1.00},
  // The scope that goes with the ref_id PARENT_OF seeds. Not a default the user is meant
  // to reconsider: a row added from the project panel is a project figure, and one added
  // from the assignment panel is an assignment figure.
  MonthlyEstimate:    {scope: () => S.tab === "t-proj" ? "project" : "assignment"},
};

/** One past the highest sequence number among a parent's own children. */
function nextSeq(sheet, col, parentCol, parentVal){
  let max = 0;
  for (const r of (S.model.raw[sheet] || [])){
    if (parentCol && parentVal !== null && parentVal !== undefined
        && r[parentCol] !== parentVal) continue;
    const n = num(r[col]);
    if (n !== null && n !== undefined && isFinite(n)) max = Math.max(max, n);
  }
  return max + 1;
}

/** The columns a new row is given without the user typing anything: its identifier, its
 *  parent key, and the defaults above. A row carrying ONLY those is still an empty row -
 *  the application filled it in, not the user - so it stays out of validation and out of
 *  the export until something else is entered. */
function autoFilled(sheet){
  const out = new Set(Object.keys(NEW_ROW[sheet] || {}));
  if (KEY_COL[sheet]) out.add(KEY_COL[sheet]);
  const p = PARENT_OF[sheet];
  if (p) out.add(p()[0]);
  return out;
}
function isSkeleton(sheet, r){
  const auto = autoFilled(sheet);
  return (S.headers[sheet] || []).every(h => {
    if (auto.has(h)) return true;
    const v = r[h];
    return v === null || v === undefined || String(v).trim() === "";
  });
}

function suggestionsFor(sheet, col, row){
  const M = S.model;
  const px = proxyFor(sheet, col);
  if (px) return px.options();
  const named = LIST_FOR[col];
  if (named && M.lists[named]) return M.lists[named].map(String);
  // period_name and role_name depend on the project's TYPE, so the valid set is not one
  // list but two. Narrow it by the row's own project where that is knowable.
  if (col === "period_name" || col === "role_name"){
    const pid = row && (row.project_id ||
      (row.assignment_id && (M.assignments.find(a => a.assignment_id === row.assignment_id) || {}).project_id));
    const ty = pid && (M.projects[pid] || {}).project_type;
    const kind = col === "period_name" ? "period_name" : "role";
    if (ty) return (M.lists[`${kind}_${CLINICAL_TYPES.has(ty) ? "clinical" : "others"}`] || []).map(String);
    return [...(M.lists[`${kind}_clinical`] || []), ...(M.lists[`${kind}_others`] || [])].map(String);
  }
  if (SHEET_COLS[sheet] && (SHEET_COLS[sheet].date.includes(col))) return [];
  const seen = new Set();
  for (const r of (M.raw[sheet] || [])){
    const v = r[col];
    if (v !== null && v !== undefined && !(v instanceof Date) && String(v).trim() !== "")
      seen.add(String(v));
  }
  return seen.size > 1 && seen.size <= 400 ? [...seen].sort() : [];
}

/** One editable table.
 *  `derived` maps a display-only column to a lookup - shown for context, never typed
 *  into, because the master row is the truth and V-13 exists to say so. */
/* Sheets whose ROW SET is fixed by the schema, not by the user.
 *
 *  Config is the only one today. Its nine settings are read BY NAME - a tenth row nobody
 *  reads does nothing, and a missing row silently hands the figure to a built-in default.
 *  So there is nothing to add and nothing that should be removed: what a user changes
 *  here is a VALUE, and the value cell is as editable as any other.
 *
 *  Deleting one of them was the sharp edge. It could not be refused - nothing references
 *  a Config row, so V-17 had no hold on it - and it raised nothing, so a plan whose
 *  under-allocation floor had been moved to 0.80 would revert to 0.60 with every
 *  dependent figure changing and nothing on screen saying why. Removing the control is a
 *  better answer than confirming it: there was never a good reason to press it.
 *
 *  '+ row' goes with it, and for the same reason rather than for symmetry - offering a
 *  way to create a row that can then never be removed would be a worse trap than the one
 *  being closed. V-30 covers the case where a row is missing anyway, from an older file
 *  or a hand-edited one. */
const FIXED_ROWS = new Set(["Config"]);
const FIXED_ROWS_WHY = "These settings are a fixed set — change a value, and it applies "
  + "everywhere. Rows cannot be added or removed: each one is read by name, so a new row "
  + "would do nothing and a missing one would hand the figure to a built-in default.";

/* ---------------------------------------------------------------- column filters

   ONE TEXT PER CELL, used by three things that must agree: the cell as drawn, the list
   of values the filter offers, and the test of whether a row passes. A Date shown as
   2026-09-01 and matched as a Date object would offer a value nothing could match. */
function cellText(sheet, r, c, derived){
  if (derived && derived[c]) return String(derived[c](r) ?? "");
  const px = proxyFor(sheet, c);
  if (px) return String(px.show(r) ?? "");
  const v = r[c];
  return v instanceof Date ? ymd(v) : (v === null || v === undefined ? "" : String(v));
}

/** What a column is currently narrowed to, or null for "everything". */
const colFilterOf = (sheet, col) => ((S.colf[sheet] || {})[col]) || null;
const anyColFilter = sheet => Object.keys(S.colf[sheet] || {}).length > 0;

/** Rows passing every column filter EXCEPT `skip`.
 *
 *  `skip` is what makes the panel behave the way a spreadsheet's does: the values a
 *  column offers are the ones still reachable given the OTHER columns, so narrowing by
 *  project type leaves only that type's phases on the phase filter.
 *
 *  The column being edited is excluded from ITS OWN filter, which is what lets a choice
 *  be widened again rather than only narrowed. It is not excluded from the others, so
 *  after type=Biosimilar AND phase=Phase 1 the type filter offers only the types that
 *  have a Phase 1 row - the same thing a spreadsheet does, and the same way out of it:
 *  clear the other column. `Clear the filters on this table` is offered wherever the
 *  filters have emptied the table, which is when that corner is actually reached. */
function passColFilters(sheet, rows, cols, derived, skip){
  const active = cols.filter(c => c !== skip && colFilterOf(sheet, c));
  if (!active.length) return rows;
  return rows.filter(r =>
    active.every(c => colFilterOf(sheet, c).has(cellText(sheet, r, c, derived))));
}

const BLANK_LABEL = "(blank)";

/* What the filter panel needs and the DOM cannot give it.
 *
 * The panel offers the values a column COULD take, which includes values on rows another
 * column's filter is currently hiding - so reading them back off the rendered <table>
 * would offer only what is already on screen, and a filter could never be widened. The
 * renderer therefore leaves the rows it was given here, keyed by sheet.
 *
 * One entry per sheet is enough: only one pane is drawn at a time, so the two Monthly
 * estimation tables (one on each source tab) can never both be live. */
const FTABLE = {};

/** One head for every pop-up about a column: the plain name, with the column's own name
 *  beside it in the quieter type. Said the same way on the heading, on a cell and on a
 *  filter button, so a reader who learns it once reads it everywhere. */
const colHead = c => COLUMN_LABEL[c]
  ? `<b>${esc(COLUMN_LABEL[c])}</b> <span class="tr">${esc(c)}</span>`
  : `<b>${esc(c)}</b>`;

/* WHICH COLUMNS STAY PUT WHILE THE TABLE SCROLLS SIDEWAYS (R-53).
 *
 * The Project sheet is twenty-five columns and about 3,070px wide; the panel that holds
 * it is 1,316px, so less than half of it is on screen at once and a reader who scrolls
 * out to 'Figures come from' is editing an unlabelled row. What they have lost is not
 * the data, it is WHICH PROJECT THIS IS - and that is two columns, not twenty-five.
 *
 * So the identity travels with the view: the row's own handle, its identifier and its
 * name are frozen at the left edge and everything else slides under them. It is declared
 * HERE, per sheet, rather than passed in at each call site - the same sheet pinned one
 * way in one place and another way in another would be a defect rather than a choice -
 * and only a LEADING run of columns can be frozen, because what makes the arithmetic of
 * the offsets work is that there is nothing between them and the edge.
 *
 * The cost is honest and bounded: 116 + 110 + 210 = 436px of the panel, which is about
 * six data columns on screen at a time instead of ten. Six you can attribute to a project
 * beats ten you cannot.
 */
const PINNED = {Project: ["project_id", "project_name"]};

/** The pin class for each column position, "" where there is none. */
function pinCols(sheet, cols){
  const want = PINNED[sheet] || [];
  const out = cols.map(() => "");
  for (let i = 0; i < cols.length && i < want.length; i++){
    if (!want.includes(cols[i])) break;
    out[i] = "pin" + (i + 1);
  }
  return out;
}

function dataTable(sheet, rows, cols, selKey, selVal, derived, lock, filterable){
  derived = derived || {};
  if (filterable) FTABLE[sheet] = {rows, cols, derived};
  /* Rows still being typed are never filtered out. A draft has empty cells by
     definition, so any filter would hide the row the user is working in - and they
     would have no way to know why it vanished. */
  const shown = filterable
    ? rows.filter(r => r.__new || passColFilters(sheet, [r], cols, derived, null).length)
    : rows;
  const PIN = pinCols(sheet, cols);
  const pinned = PIN.filter(Boolean).length;
  const head = `<th class="ins" data-tip="${att(HELP.rowactions)}">Row</th>`
    + cols.map((c, ci) => {
        const h = COLUMN_HELP[c], px = proxyFor(sheet, c);
        const d = derived[c] ? " · shown for context, looked up from its master row and not editable"
          : px ? ` · type the name here and ${esc(px.into)} follows. Not stored on this row — `
               + `the master row owns it.` : "";
        const on = filterable && colFilterOf(sheet, c);
        const fb = filterable
          ? `<button type="button" class="fbtn${on ? " on" : ""}" data-fsheet="${att(sheet)}" `
            + `data-fcol="${att(c)}" tabindex="-1" aria-label="Filter ${att(c)}" `
            + `data-tip="${att(on ? `${colHead(c)}<br>narrowed to ${on.size} value(s)`
                                   + `<br><span class="tr">click to change</span>`
                                 : `<b>Filter ${esc(c)}</b><br>Pick the values to keep. `
                                   + `Filters on different columns narrow together.`)}">`
            + `&#9662;</button>` : "";
        /* THE HEADING IS THE PLAIN NAME. The workbook's own column name is not printed
           here - it is in the pop-up, which every heading now carries, and on the
           element as data-cid.

           It was shown on a second line for one release, on the reasoning that the
           screen and the file are the same thing and a heading you cannot find in the
           spreadsheet is one you cannot quote or look up. That reasoning was right about
           the NEED and wrong about the PLACE: the need is occasional - you go looking for
           a column name when you are editing the workbook or reading a finding - and the
           heading is read on every glance by everyone. Paying for a rare need out of the
           common one is the wrong trade, and the pop-up already answers it in full.

           data-cid is not decoration. It is what a test reads to check a heading names a
           real column of its sheet, and it keeps the identifier in the DOM for anything
           else that needs it, now that the text no longer carries it. */
        const lab = COLUMN_LABEL[c] || c;
        return `<th class="hasinfo${PIN[ci] ? " " + PIN[ci] : ""}" data-cid="${att(c)}" `
          + `data-tip="${att(`${colHead(c)}<br>${(h||"")}${d}`)}">`
          + `<span class="lab">${esc(lab)}</span>`
          + `${derived[c] ? ' <span class="drv">lookup</span>'
                          : px ? ' <span class="drv ent">sets '
                                 + esc(COLUMN_LABEL[px.into] || px.into) + '</span>' : ""}${fb}</th>`;
      }).join("");
  const body = shown.map(r => {
    const sel = (selKey && r[selKey] === selVal) ? ' class="sel"' : "";
    const tds = cols.map((c, ci) => {
      const pin = PIN[ci] ? " " + PIN[ci] : "";
      if (derived[c]){
        const dv = derived[c](r) ?? "";
        /* NAMED, so the stylesheet can give one derivation the width it needs without
           widening every lookup column in the application. data-drv rather than data-col:
           data-col is what makes a cell editable and what the editing code writes back
           through, and a read-only cell must not carry it. */
        return `<td class="muted drvcell${pin}" data-drv="${att(c)}" data-tip="${att(
            `${colHead(c)}<br>${esc(dv).replace(/\n/g, "<br>") || "&mdash;"}`
          + `<br><span class="tr">looked up, not stored on this row</span>`)}">${esc(dv)}</td>`;
      }
      const px = proxyFor(sheet, c);
      if (px){
        const pv = px.show(r) ?? "";
        const marked = S.editedCells.has(`${sheet}|${r.__row}|${px.into}`) ? " edited" : "";
        return `<td class="cell${marked}${pin}" contenteditable="true" data-sheet="${att(sheet)}" `
          + `data-row="${r.__row}" data-col="${att(c)}" data-tip="${att(
              `${colHead(c)}<br>${pv === "" ? "<i>empty</i>" : esc(pv)}`
              + `<br><span class="tr">typing a name here sets ${esc(px.into)}</span>`)}">${esc(pv)}</td>`;
      }
      const v = r[c];
      const disp = v instanceof Date ? ymd(v) : (v === null || v === undefined ? "" : v);
      const marked = S.editedCells.has(`${sheet}|${r.__row}|${c}`) ? " edited" : "";
      const help = COLUMN_HELP[c] ? `<br><span class="tr">${esc(COLUMN_HELP[c])}</span>` : "";
      const tip = `${colHead(c)}<br>${disp === "" ? "<i>empty</i>" : esc(disp)}${help}`;
      /* The colour a highlight names, shown in the cell as a small square - as an
         ATTRIBUTE the stylesheet draws from, never as an element inside the cell. The
         cell is contenteditable and what is typed in it is read straight back off the
         DOM, so a chip that lived in the cell's own content would be part of the value:
         one stray keystroke and the mark becomes text nobody meant to type. A pseudo
         element cannot be edited, selected or copied by accident. */
      const hl = c === "milestone_highlight" ? hlToken(v) : "";
      return `<td class="cell${marked}${pin}" contenteditable="true" data-sheet="${att(sheet)}" `
        + `data-row="${r.__row}" data-col="${att(c)}"${hl ? ` data-hl="${att(hl)}"` : ""} `
        + `data-tip="${att(tip)}">${esc(disp)}</td>`;
    }).join("");
    return `<tr${sel} data-id="${att(r[selKey] ?? "")}">`
      + (FIXED_ROWS.has(sheet)
          ? `<td class="ins muted" data-tip="${att(HELP.fixedrows)}">&#8212;</td>`
          : `<td class="ins"><button class="btn tiny" data-ins="${att(sheet)}" data-after="${r.__row}"`
            + ` data-tip="${att(HELP.insert)}">+ row</button>`
            + `<button class="btn tiny danger" data-del="${att(sheet)}" data-row="${r.__row}"`
            + ` data-tip="${att(HELP.del)}">Delete</button></td>`)
      + `${tds}</tr>`;
  }).join("");
  // A locked table has a reason instead of a + row: a child row whose parent does not
  // exist yet has nothing to attach to, and would be dropped when the file is read back.
  // Saying so where the button would have been beats offering a button that creates a
  // row nobody can rescue.
  /* A table emptied BY A FILTER is a different situation from a table with nothing in
     it, and offering '+ row' there would be wrong twice over: the plan is not empty, and
     a new row would almost certainly fail the filter and vanish as it was created. Say
     what happened and offer the way out. */
  const hiddenByFilter = filterable && rows.length && !shown.length;
  const empty = shown.length ? "" : hiddenByFilter
    ? `<tr><td class="ins muted">&#8212;</td>`
      + `<td class="muted" colspan="${cols.length}">All ${rows.length} row(s) are hidden by `
      + `the column filters. <button class="btn tiny" data-fclear="${att(sheet)}">`
      + `Clear the filters on this table</button></td></tr>`
    : FIXED_ROWS.has(sheet)
    ? `<tr><td class="ins muted">&#8212;</td>`
      + `<td class="muted" colspan="${cols.length}">${esc(FIXED_ROWS_WHY)}</td></tr>`
    : lock
    ? `<tr><td class="ins muted">—</td>`
      + `<td class="muted" colspan="${cols.length}">${esc(lock)}</td></tr>`
    : `<tr><td class="ins"><button class="btn tiny" data-ins="${att(sheet)}" data-after="0" `
      + `data-tip="${att(HELP.insert)}">+ row</button></td>`
      + `<td class="muted" colspan="${cols.length}">No rows. Use <strong>+ row</strong> to add one.</td></tr>`;
  /* How many rows the filters are holding back, said above the table rather than only
     implied by a shorter list - a filter left on from ten minutes ago is otherwise
     indistinguishable from data that is not there. */
  const note = filterable && anyColFilter(sheet) && shown.length
    ? `<p class="note fnote">Showing <strong>${shown.length}</strong> of ${rows.length} row(s) — `
      + `column filters are on. <button class="btn tiny" data-fclear="${att(sheet)}">`
      + `Clear them</button></p>` : "";
  return note + `<div class="scrollx tall"><table class="data-t" data-sheet="${att(sheet)}"`
    + `${pinned ? ` data-pin="${pinned}"` : ""}`
    + `${filterable ? ' data-filterable="1"' : ""}>`
    + `<thead><tr>${head}</tr></thead><tbody>${body}${empty}</tbody></table></div>`;
}

/** dataTable with the per-column filters turned on. The six tables a reviewer asked for
 *  are wide and long enough to need them; a four-row child sub-table is not, and a funnel
 *  on every heading in the application would be noise where it is not useful. */
const filterTable = (sheet, rows, cols, selKey, selVal, derived, lock) =>
  dataTable(sheet, rows, cols, selKey, selVal, derived, lock, true);

