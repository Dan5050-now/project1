
/** Begin a plan with nothing in it but the standard vocabulary and settings. */
function startBlank(){
  mayReplacePlan("Starting a new plan", startBlankNow);
}
function startBlankNow(){
  try {
    adopt(blankSheets(), "New plan (not yet exported)", {
      blank: true,
      // The project tab, not Overall: Overall would open on an empty dashboard, and the
      // first thing to do is enter a project.
      tab: "t-proj",
      banner: "New plan started. Add your first project below — then its milestones, "
        + "your people, and who works on what. Period weights and role factors are "
        + "placeholders at 1.00 until you set them on General assumptions. Nothing is on "
        + "disk until you press Export.",
    });
  } catch (e){
    showBanner("bad", `Could not start a new plan: ${e.message}`);
    console.error(e);
  }
}

el("vers").textContent = `v${APP_VERSION} · expects source schema v${SCHEMA_EXPECTED}`;

el("loadBtn").onclick = el("loadBtn2").onclick = () => el("picker").click();
el("startBtn").onclick = startBlank;
/* Two defects in one line, both reported from the field.

   THE VALUE IS RESET FIRST. <input type=file> fires `change` only when its value
   CHANGES, so choosing the same file twice did nothing at all - and "export, edit in
   Excel, load the same filename back" is the ordinary working loop of this application.
   Clearing the value makes every pick a change, including a repeat of the last one.

   AND THE PLAN IS NOT REPLACED WITHOUT ASKING. adopt() resets S.pending, so a stray
   click on Load threw away unsaved work in silence. */
el("picker").onchange = e => {
  const f = e.target.files[0];
  e.target.value = "";
  if (f) mayReplacePlan(`Loading ${f.name}`, () => loadFile(f));
};
/* The export menu. Each item closes it before acting, so the panel is not left hanging
   open over a banner that is reporting what just happened. */
const expDone = fn => () => { el("expMenu").open = false; fn(); };
el("exportBtn2").onclick = expDone(() => exportWorkbook(false));
el("exportJsonBtn").onclick = expDone(() => exportWorkbook(true));
el("exportCalcBtn").onclick = expDone(exportResults);
el("whoOk").onclick = () => setWho(el("whoName").value);
el("whoSkip").onclick = () => setWho("");
el("whoName").addEventListener("keydown", e => {
  if (e.key === "Enter"){ e.preventDefault(); setWho(el("whoName").value); }
});
el("repClose").onclick = () => el("report").close();
el("gapClose").onclick = () => closeGap();
/* A Stated cell with no row behind it yet. Its own listener rather than applyEdit's,
   because there is no row to write through - see stateMonth() for the two cases and why
   only one of them asks. Registered once, on the document, like every other cell
   handler; the dialog's contents are replaced on every redraw, so anything bound to the
   cells themselves would be lost the first time a figure changed. */
document.addEventListener("focusin", e => {
  const td = e.target.closest("td[data-gapnew]");
  if (td) td.dataset.orig = td.textContent;
});
document.addEventListener("focusout", e => {
  const td = e.target.closest("td[data-gapnew]");
  if (td && td.textContent !== (td.dataset.orig ?? "")) stateMonth(td);
});
/* An empty place in an assumption matrix (R-69): a cell that creates its row. The same
   shape as the Stated cell above - no data-sheet, so the ordinary commit leaves it alone -
   and the caret goes on to where it was going, as it does from any other cell. */
document.addEventListener("focusin", e => {
  const td = e.target.closest("td[data-mknew]");
  if (td) td.dataset.orig = td.textContent;
});
document.addEventListener("focusout", e => {
  const td = e.target.closest("td[data-mknew]");
  if (!td || td.textContent.trim() === "" || td.textContent === (td.dataset.orig ?? "")) return;
  const next = e.relatedTarget, scope = next && next.closest ? next.closest("section.tab") : null;
  const FOCUSABLE = 'td[contenteditable="true"], button:not([disabled]), input, select';
  const at = scope ? [...scope.querySelectorAll(FOCUSABLE)].indexOf(next) : -1;
  matrixCreate(td);
  if (scope && at >= 0 && !next.isConnected){
    const again = scope.querySelectorAll(FOCUSABLE)[at];
    if (again) again.focus();
  }
});
el("gapClose").onclick = () => closeGap();
// Escape and the backdrop close it too; GAP_AT has to be cleared either way or a
// later edit would redraw a dialog nobody has open.
el("gapdlg").addEventListener("close", () => closeGap());
/* The list the month is opened FROM. Nothing to clear when it shuts - what it shows is
   derived from S.calc and redrawn each time it is opened - so the close listener only
   exists so Escape and the backdrop go through the same function the button does. */
/* The smallest-gap field answers as it is typed rather than on blur - the figure is a
   dial being turned, not a value being committed - so the list is redrawn and the focus
   and caret put back where they were. Redrawing is what keeps the pills and the "n of m"
   line honest; leaving the field alone and filtering the rows only would let those two
   disagree with what is on screen. */
document.addEventListener("input", e => {
  if (e.target.id !== "gapfMin") return;
  S.gapf.min = e.target.value;
  const at = e.target.selectionStart;
  openGaps();
  const again = el("gapfMin");
  if (again){
    again.focus();
    try { again.setSelectionRange(at, at); } catch (_){ /* number inputs may refuse */ }
  }
});
el("gapsClose").onclick = () => closeGaps();
el("gapsdlg").addEventListener("close", () => closeGaps());
el("cfgClose").onclick = () => el("cfgchg").close();
el("chgBtn").onclick = () => { renderChanges(); el("changes").showModal(); };
el("chgClose").onclick = () => el("changes").close();
el("chgBig").onclick = () => {
  const d = el("changes"), big = d.classList.toggle("big");
  el("chgBig").textContent = big ? "Exit full screen" : "Full screen";
  cueScrollers();                       // the box changed size, so its edge cues have too
};
el("themeBtn").onclick = () => {
  const r = document.documentElement;
  const dark = r.dataset.theme ? r.dataset.theme === "dark"
             : matchMedia("(prefers-color-scheme: dark)").matches;
  r.dataset.theme = dark ? "light" : "dark";
};

const drop = el("drop");
["dragenter","dragover"].forEach(ev => drop.addEventListener(ev, e => {
  e.preventDefault(); drop.classList.add("on"); }));
["dragleave","drop"].forEach(ev => drop.addEventListener(ev, e => {
  e.preventDefault(); drop.classList.remove("on"); }));
/* Dropping a file replaces the plan exactly as the picker does, so it asks the same
   question. Easier to do by accident than the picker, if anything. */
drop.addEventListener("drop", e => {
  const f = e.dataTransfer.files[0];
  if (f) mayReplacePlan(`Loading ${f.name}`, () => loadFile(f));
});

for (const id of Object.keys(FILTER_KEY))
  el(id).addEventListener("change", e => {
    if (e.target.classList.contains("msq")) return;     // the search box filters nothing
    msSummary(el(id)); readFilters(); fitHorizon(); renderKeepingTab(); });

/* The search box in a long filter list hides the entries that do not match; it never
   ticks or unticks anything, so what is filtered is still exactly what is ticked. */
document.addEventListener("input", e => {
  const q = e.target.closest && e.target.closest(".msq");
  if (!q) return;
  const want = q.value.trim().toLowerCase();
  for (const l of q.parentNode.querySelectorAll("label[data-find]"))
    l.hidden = !!want && !l.dataset.find.includes(want);
});

/* Clear one filter without hunting for the ticks that are still on. */
document.addEventListener("click", e => {
  const c = e.target.closest("[data-msclear]");
  if (!c) return;
  const d = el(c.dataset.msclear);
  for (const i of d.querySelectorAll("input[type=checkbox]")) i.checked = false;
  msSummary(d); readFilters(); fitHorizon(); renderKeepingTab();
});
/* Keep an open panel inside the window.
 *
 * The panels hang from the left edge of their control, which is right until the control
 * itself is near the right edge of the window: at 1280px the Role filter lands there and
 * its panel finished 4px past the edge, clipped. The Export menu never had the problem
 * because it is the rightmost control and was pinned `right:0` from the start - this is
 * the same pin, applied to whichever panel needs it, decided when it opens rather than
 * guessed from a breakpoint. The filter bar wraps, so which control sits at the edge
 * depends on the window width and on how long the labels are; measuring is the only
 * honest way to know.
 *
 * Re-measured on every open because both of those can change under it. */
function fitPanel(d){
  const p = d.querySelector(".msp");
  if (!p) return;
  p.style.left = p.style.right = "";          // measure it where it wants to be
  if (p.getBoundingClientRect().right > document.documentElement.clientWidth - 8){
    p.style.left = "auto"; p.style.right = "0";
  }
}
document.addEventListener("toggle", e => {
  const d = e.target.closest && e.target.closest("details.ms");
  if (d && d.open) fitPanel(d);
}, true);   // capture: `toggle` does not bubble

/* One open at a time, and clicking anywhere else puts them all away - <details> keeps
   itself open otherwise, and seven panels left hanging over the page would bury it. */
document.addEventListener("click", e => {
  for (const d of document.querySelectorAll("details.ms"))
    if (d.open && !d.contains(e.target)) d.open = false;
});
document.addEventListener("keydown", e => {
  if (e.key !== "Escape") return;
  for (const d of document.querySelectorAll("details.ms")) d.open = false;
});
/* PICKING ONE SERIES OUT OF A CHART.
 *
 * Twenty bands in twenty shades of one palette read perfectly well as a total and not at
 * all as a series: finding one project in the stack by colour alone means carrying a
 * swatch in your head down sixty months of bars. Clicking its legend entry fades back
 * everything that is not it.
 *
 * THE PICK APPLIES TO THE WHOLE TAB, not to the chart the legend belongs to. Series keys
 * are ids, and the same project is the same id on its trend line, its band in the stack
 * and its row on the timeline - so one click answers "where is this project on this
 * page", which is the question actually being asked, rather than "where is it in this
 * one drawing", which is already obvious from the legend.
 *
 * The current pick is READ BACK OUT OF THE DOM rather than kept in a variable. Every
 * render replaces the charts wholesale; a remembered key would survive the marks it
 * referred to, and the first click after a render would be read as "you picked that
 * already" and silently do nothing. A class on a legend entry cannot outlive the legend.
 */
const PICK = {
  /** Everything one pick covers: the tab, or the dialog if the chart is inside one. */
  root: node => node.closest("dialog[open], section.tab") || document.body,
  /** A mark may stand for two series at once - see `sKey` in the charts. */
  is: (m, key) => m.getAttribute("data-s") === key || m.getAttribute("data-s2") === key,
  /** `key` empty puts every chart back.
   *
   *  A CHART THAT DOES NOT KNOW THE KEY IS LEFT ALONE. The tab holds charts cut along
   *  different axes - by project, by person, by period - and a person's id means nothing
   *  to a chart stacked by project. Dimming it anyway would fade a whole chart to
   *  nothing and light none of it, which reads as "this project has no data" rather
   *  than "you asked a question this chart cannot answer". So each chart is asked first
   *  whether it has a mark for the key, and only the ones that do respond. */
  apply(root, key){
    for (const svg of root.querySelectorAll("svg.chart")){
      const marks = [...svg.querySelectorAll("[data-s]")];
      const known = !!key && marks.some(m => PICK.is(m, key));
      svg.classList.toggle("picked", known);
      for (const m of marks) m.classList.toggle("hi", known && PICK.is(m, key));
      /* The legend sits OUTSIDE the svg, beside it in the same scrolling box. It fades
         its own other entries only when it actually offers this one: the timeline's
         legend names periods, so a project pick lights its bands without touching a
         list that has nothing to say about projects. */
      for (const ul of (svg.parentNode || root).querySelectorAll(":scope > ul.legend")){
        const lis = [...ul.querySelectorAll("li[data-s]")];
        const offered = known && lis.some(li => li.getAttribute("data-s") === key);
        ul.classList.toggle("picked-leg", offered);
        for (const li of lis){
          const on = offered && li.getAttribute("data-s") === key;
          li.classList.toggle("on", on);
          li.setAttribute("aria-pressed", on ? "true" : "false");
        }
      }
    }
  },
  toggle(li){
    const root = PICK.root(li), key = li.getAttribute("data-s");
    const cur = root.querySelector("ul.legend li[data-s].on");
    PICK.apply(root, cur && cur.getAttribute("data-s") === key ? "" : key);
  },
  /** Asked of the CHARTS rather than of the legends: a pick can light a chart whose own
   *  legend does not offer the key - the timeline under a project pick - so a chart left
   *  dimmed is the thing to look for, not a legend left faded. */
  clear(){
    for (const svg of document.querySelectorAll("svg.chart.picked")) PICK.apply(PICK.root(svg), "");
  }
};
document.addEventListener("click", e => {
  const li = e.target.closest && e.target.closest("ul.legend li[data-s]");
  if (li) PICK.toggle(li);
});
document.addEventListener("keydown", e => {
  // Enter and Space on a focused entry, because a legend entry is a button (D-04).
  if (e.key === "Enter" || e.key === " "){
    const li = e.target.closest && e.target.closest("ul.legend li[data-s]");
    if (li){ e.preventDefault(); PICK.toggle(li); return; }
  }
  if (e.key === "Escape") PICK.clear();
});

for (const id of ["fFrom","fTo"])
  el(id).addEventListener("change", () => { readFilters(); renderKeepingTab(); });
el("fAll").onclick = () => { S.from = S.calc.lo; S.to = S.calc.hi;
  if (S.to - S.from > 120) S.to = S.from + 120; writeHorizon(); renderKeepingTab(); };
el("fReset").onclick = () => {
  for (const id of Object.keys(FILTER_KEY)){
    for (const i of el(id).querySelectorAll("input")) i.checked = false;
    el(id).open = false;
    msSummary(el(id));
  }
  defaultHorizon(); readFilters(); renderKeepingTab();
};

document.addEventListener("click", e => {
  const tab = e.target.closest("nav button");
  if (tab){ showTab(tab.dataset.tab); window.scrollTo({top:0}); return; }
  /* An issue month opens its own dialog (R-62) - and it is asked BEFORE the row it sits
     in. A project row's click expands it, and when that came first a click on a marked
     month only ever folded the project open or shut: the month, and the review it
     carries, could not be reached from the cell at all. */
  const gp = e.target.closest("[data-gap]");
  if (gp){
    e.stopPropagation();
    openGap(gp.dataset.gap, +gp.dataset.gk, gp.dataset.gapis || "");
    return;
  }
  /* A name in the Overall tables, the Data issues tab or a card itself opens that
     project's or person's card (R-69) - before the row, whose own click would fold it
     open or shut. A name in an editable table is left to the end of this handler,
     because there the row is selected as well. */
  const cl = e.target.closest("[data-card]");
  if (cl && !cl.closest(".data-t tbody tr")){
    e.stopPropagation();
    openCard(cl.dataset.card, cl.dataset.cid, !!cl.closest("#carddlg"));
    return;
  }
  /* The project's team (R-66) - also before the row, whose own click would fold it. */
  const tb = e.target.closest("[data-team]");
  if (tb){
    e.stopPropagation();
    openTeam(tb.dataset.team);
    return;
  }
  const parent = e.target.closest("tr.parent");
  if (parent){
    const k = parent.dataset.k;
    S.expanded.has(k) ? S.expanded.delete(k) : S.expanded.add(k);
    renderKeepingTab(); return;
  }
  // Which project type's derivation rules are shown (R-70).
  const prt = e.target.closest("[data-prtype]");
  if (prt){
    S.genView.prule = prt.dataset.prtype;
    keepScroll(() => renderTab("t-gen"));
    const b = document.querySelector(`#t-gen [data-prtype="${CSS.escape(prt.dataset.prtype)}"]`);
    if (b) b.focus({preventScroll:true});
    return;
  }
  const vt = e.target.closest("[data-setview]");
  if (vt){
    const [id, mode] = vt.dataset.setview.split("|");
    S.genView[id] = mode;
    /* renderTab rather than renderGenTab, which is what this used to call. The pane it
       builds is identical - renderTab looks the function up and calls it - but it is also
       where a pane is put back into the state it was in, and going straight to the
       renderer was the one path that skipped that. Switching Role factors between Matrix
       and Rows while it had the whole screen gave the page back. */
    keepScroll(() => renderTab("t-gen"));
    return;
  }
  /* V-34, opened from wherever it is marked: the panel row, its button, the tile above
     it, or the marked cell in Resource by project. stopPropagation because a marked
     cell sits inside a row whose own click expands it - without this, asking about the
     month would also toggle the project open underneath the dialog. */
  /* The tile, and the control in Resource by project's head, open the same list (R-52).
     The tile still has to change tab first - it may be reached from a chart pop-up on
     another tab - while the control is already on Overall. */
  /* The list's own filter (R-53). Redraws the list in place - the dialog stays open,
     because the whole point of narrowing is to go on reading the same screen. Before the
     row handler below, since these controls sit above the rows rather than inside one. */
  const gd = e.target.closest("[data-gapdir]");
  if (gd){ e.stopPropagation(); S.gapf.dir = gd.dataset.gapdir; openGaps(); return; }
  const gv = e.target.closest("[data-gaprev]");
  if (gv){ e.stopPropagation(); S.gapf.rev = gv.dataset.gaprev; openGaps(); return; }
  /* The manager's review, from inside the month dialog (R-62). */
  const rs = e.target.closest("[data-revsave], [data-revclear]");
  if (rs){
    e.stopPropagation();
    if (rs.hasAttribute("data-revclear")) clearReview();
    else saveReview();
    return;
  }
  if (e.target.closest("[data-gapclear]")){
    e.stopPropagation();
    S.gapf = {dir:"", proj:"", min:0, rev:""};
    openGaps();
    return;
  }
  const gj = e.target.closest("[data-gapjump], [data-gapopen]");
  if (gj){
    e.stopPropagation();
    if (gj.hasAttribute("data-gapjump")) showTab("t-overall");
    openGaps();
    return;
  }
  const act = e.target.closest("[data-act]");
  if (act){
    e.stopPropagation();
    // Opening the other tab from INSIDE the gap dialog has to shut it first, or the tab
    // it just took you to is drawn behind a modal nobody asked to keep.
    if (act.dataset.act === "gopers" || act.dataset.act === "goproj"){ closeGap(); closeGaps(); closeCard(); }
    if (act.dataset.act === "blankms") blankMilestones(act.dataset.pid);
    if (act.dataset.act === "autoper") autoPeriods(act.dataset.pid);
    if (act.dataset.act === "blankper") blankPeriods(act.dataset.pid);
    if (act.dataset.act === "estswitch") switchEstimation(act.dataset.scope, act.dataset.id);
    if (act.dataset.act === "estfill") fillEstimates(act.dataset.scope, act.dataset.id);
    /* Period derivation rules (R-70): a rule for a period that has none - with the caret
       put in it - and a type's standard rules laid out. */
    if (act.dataset.act === "pruleadd"){
      const r = addPeriodRule(act.dataset.type, act.dataset.period);
      rebuild(true);
      renderKeepingTab();
      const td = r && document.querySelector(`#t-gen td[data-sheet="PeriodRule"]`
        + `[data-row="${r.__row}"][data-col="end_milestone"]`);
      if (td) td.focus();
    }
    if (act.dataset.act === "prulestd") layOutStandardRules(act.dataset.type);
    /* The two levels of a manual figure are on different tabs, and the question the
       panel raises - "which assignment is stated, and what does it say" - is only
       answerable on the other one. So it takes you there, with the row already
       selected, rather than naming it and leaving you to find it. */
    if (act.dataset.act === "gopers"){
      S.selPers = act.dataset.sid;
      S.selAsg = act.dataset.aid;
      showTab("t-pers"); renderAll(); showTab("t-pers");
    }
    if (act.dataset.act === "goproj"){
      S.selProj = act.dataset.pid;
      showTab("t-proj"); renderAll(); showTab("t-proj");
    }
    return;
  }
  const ins = e.target.closest("[data-ins]");
  if (ins){
    e.stopPropagation();
    const sheet = ins.dataset.ins, after = +ins.dataset.after;
    const rows = S.model.raw[sheet];
    const i = rows.findIndex(r => r.__row === after);
    const blank = {__row: Math.max(0, ...rows.map(r => r.__row)) + 1, __new:true};
    for (const h of (S.headers[sheet] || [])) blank[h] = null;
    if (PARENT_OF[sheet]){
      const [col, val] = PARENT_OF[sheet]();
      if (val) blank[col] = val;
    }
    if (AUTO_KEY.has(sheet)){
      const id = nextKey(sheet, KEY_COL[sheet]);
      if (id) blank[KEY_COL[sheet]] = id;
    }
    for (const [col, v] of Object.entries(NEW_ROW[sheet] || {}))
      if (S.headers[sheet] && S.headers[sheet].includes(col))
        blank[col] = typeof v === "function" ? v() : v;
    rows.splice(i + 1, 0, blank);                        // directly below, not appended
    /* A NEW PROJECT OR PERSON IS THE SELECTION FROM THE MOMENT IT EXISTS (R-56). The
       panels below - milestones, periods, assignments - follow the selection, and so
       does the parent a child row is seeded with. Left on the row the + was pressed
       from, the details typed next went to that project instead of the new one. */
    const nk = blank[KEY_COL[sheet]];
    if (nk && (sheet === "Project" || sheet === "Person")){
      S.newKeys.add(nk);
      if (sheet === "Project") S.selProj = nk;
      else { S.selPers = nk; S.selAsg = null; }
    }
    beginEditSession();
    S.pending.push({at:new Date(), sheet, row:blank.__row, col:"(new row)",
                    from:null, to:""});
    // Deliberately no rebuild: a row with every cell empty is INCOMPLETE, not invalid,
    // and the parser skips blank rows. It becomes real when a field is filled, and the
    // export guard refuses to write one that still has no identifier.
    renderKeepingTab();
    return;
  }
  const del = e.target.closest("[data-del]");
  if (del){
    e.stopPropagation();
    deleteRow(del.dataset.del, +del.dataset.row);
    return;
  }
  const row = e.target.closest(".data-t tbody tr");
  /* A name's link and its pencil (R-67). Read here, before the row is selected: the
     pencil replaces the cell's contents, and a target taken out of the page has no row
     to find any more. */
  const ren = e.target.closest("[data-rename]"), card = e.target.closest("[data-card]");
  if (ren || card) e.preventDefault();
  if (row && row.dataset.id) keepScroll(() => {
    const sheet = row.closest(".data-t").dataset.sheet;
    // Re-render the DEPENDENT panels only. Re-rendering the table itself would replace
    // the cell the click just put the caret in, so the edit could never be typed.
    if (sheet === "Project" && S.selProj !== row.dataset.id){
      S.selProj = row.dataset.id;
      for (const tr of row.parentNode.children) tr.classList.toggle("sel", tr === row);
      const d = el("projDetail"); if (d) d.innerHTML = projDetail(S.selProj);
    }
    if (sheet === "Person" && S.selPers !== row.dataset.id){
      S.selPers = row.dataset.id;
      S.selAsg = null;                   // a different person has different assignments
      for (const tr of row.parentNode.children) tr.classList.toggle("sel", tr === row);
      const d = el("persDetail"); if (d) d.innerHTML = persDetail(S.selPers);
    }
    // Selecting an assignment drives the two panels below it. Only the panels that
    // depend on it are redrawn - re-rendering the Assignments table would replace the
    // cell the click just put the caret in, so the edit could never be typed.
    if (sheet === "Assignment" && S.selAsg !== row.dataset.id){
      S.selAsg = row.dataset.id;
      for (const tr of row.parentNode.children) tr.classList.toggle("sel", tr === row);
      const d = el("asgDetail"); if (d) d.innerHTML = overridesPanel(S.selPers);
    }
  });
  if (ren) startRename(ren.closest("td"));
  else if (card) openCard(card.dataset.card, card.dataset.cid, !!card.closest("#carddlg"));
});
/* One type's derivation rules copied to another (R-70). The list puts itself back to its
   prompt whatever is answered, so choosing the same type twice asks twice. */
document.addEventListener("change", e => {
  if (e.target.id !== "pruleCopy" || !e.target.value) return;
  const from = e.target.dataset.from, to = e.target.value;
  e.target.value = "";
  copyPeriodRules(from, to);
});
/* F2 on a name's link renames it, as it would a cell in a spreadsheet (R-67). */
document.addEventListener("keydown", e => {
  if (e.key !== "F2") return;
  const b = e.target.closest && e.target.closest(".namelink");
  if (b){ e.preventDefault(); startRename(b.closest("td")); }
});

// Clicking a cell that ALREADY has the caret fires no focusin, so after Escape has
// dismissed the list there would be no way to ask for it again without clicking away
// and back. A click in the field re-opens it; SUGG.open is a no-op if it is already
// showing for that cell.
document.addEventListener("click", e => {
  const td = e.target.closest('td[contenteditable="true"]');
  if (td){ SUGG.open(td); CAL.open(td); }
});
document.addEventListener("focusin", e => {
  const td = e.target.closest('td[contenteditable="true"]');
  if (!td) return;
  // Only on a FRESH focus. Focus is also restored programmatically after a scrollbar
  // drag on the suggestion list, and re-recording `orig` there would make Escape revert
  // to the half-typed text instead of the value the cell started with.
  if (!SUGG.owns(td)) td.dataset.orig = td.textContent;
  SUGG.open(td);
  CAL.open(td);
});
document.addEventListener("focusout", e => {
  const td = e.target.closest('td[contenteditable="true"]');
  if (!td) return;
  /* A cell with no data-sheet is not a cell OVER a row: it is one offering to CREATE
     the row that does not exist yet, and it carries its own handler. Without this guard
     applyEdit would be called with an undefined sheet and a NaN row number, and
     M.raw[undefined] throws before anything can say why. */
  if (!td.dataset.sheet) return;
  /* A name being renamed goes back to its link once it is left (R-67) - after the same
     delay, so a drag on the value list's scrollbar, which takes the focus for a moment
     and gives it back, does not end the rename under the person doing it. */
  if (td.classList.contains("renaming"))
    setTimeout(() => { if (!SUGG.holding) endRename(td); }, 150);
  /* Close on a delay, and only if the panel is still THIS cell's. Clicking straight
     from one cell to the next opens the panel for the new one before this timer fires,
     and an unconditional close would then shut the panel that had just been opened -
     which looked exactly like "it only works every other click". */
  setTimeout(() => { if (!SUGG.holding && SUGG.owns(td)) SUGG.close(); }, 120);
  setTimeout(() => { if (!CAL.holding && CAL.owns(td)) CAL.close(); }, 120);
  const now = td.textContent;
  if (now === td.dataset.orig) return;
  /* AND THE CARET GOES WHERE IT WAS GOING (R-69). A commit redraws the pane - and an
     open card - so the cell a click or Tab was taking the caret to has been replaced by
     the time the browser hands it the focus, and the focus went nowhere: every field
     after the first needed a second click. The cell is found again by what it is over,
     inside the same dialog or tab, and given the focus it was on its way to. */
  /* Anything else the focus was going to - a button, Switch… beside a cell - is found
     again by its place among the things that take the focus there, which a redraw of
     the same record does not change. */
  const next = e.relatedTarget;
  const scope = next && next.closest ? next.closest("dialog[open]") || next.closest("section.tab") : null;
  const cell = next && next.matches && next.matches('td[contenteditable="true"][data-sheet]')
    ? `td[contenteditable="true"][data-sheet="${CSS.escape(next.dataset.sheet)}"]`
      + `[data-row="${CSS.escape(next.dataset.row)}"][data-col="${CSS.escape(next.dataset.col)}"]`
    : null;
  const FOCUSABLE = 'td[contenteditable="true"], button:not([disabled]), input, select, '
    + 'textarea, [tabindex="0"]';
  const at = scope ? [...scope.querySelectorAll(FOCUSABLE)].indexOf(next) : -1;
  applyEdit(td.dataset.sheet, +td.dataset.row, td.dataset.col, now, td);
  if (scope && !next.isConnected && scope.isConnected){
    const again = (cell && scope.querySelector(cell))
      || (at >= 0 ? scope.querySelectorAll(FOCUSABLE)[at] : null);
    if (again) again.focus();
  }
});
document.addEventListener("keydown", e => {
  const td = e.target.closest('td[contenteditable="true"]');
  if (!td) return;
  // Enter and Escape still behave, on a creating cell as on any other - they are the
  // two keys everybody expects from a cell, and the blur is what runs its handler.
  if (!td.dataset.sheet){
    if (e.key === "Enter"){ e.preventDefault(); td.blur(); }
    if (e.key === "Escape"){ td.textContent = td.dataset.orig ?? ""; td.blur(); }
    return;
  }
  if (SUGG.key(e)) return;                       // the list takes the key first
  if (CAL.key(e)) return;
  if (e.key === "Enter"){ e.preventDefault(); SUGG.close(); CAL.close(); td.blur(); }
  if (e.key === "Escape"){ td.textContent = td.dataset.orig ?? ""; SUGG.close(); CAL.close(); td.blur(); }
});
// A pop-up over the cell you are typing into is in the way, so it goes.
document.addEventListener("input", e => {
  if (e.target.closest('td[contenteditable="true"]')){ el("tip").hidden = true; }
});

/* A FLOATING PANEL GOES WHERE ITS CELL IS (R-67, R-69). A modal dialog is drawn in the
   top layer, above the whole page whatever anybody's z-index says, so a pop-up, the value
   list or the calendar left on the body is drawn BEHIND the dialog whose cell it serves -
   which since R-69 includes every field of a card. Each is moved into the open dialog
   that holds its cell, and back to the body otherwise. They are fixed-position either
   way, so moving one changes what it is drawn over and nothing about where. */
function lodgeIn(box, node){
  const d = node && node.closest && node.closest("dialog[open]");
  const host = d || document.body;
  if (box.parentNode !== host) host.appendChild(box);
}

/* ---- type-ahead ---- */
const SUGG = (() => {
  const box = el("sugg");
  let cell = null, items = [], idx = -1;
  const api = {holding:false};

  /** Every run of every token, merged, so each matched fragment is marked - not just
   *  the first one and not just a single contiguous stretch. */
  function markup(v, toks){
    const lv = v.toLowerCase(), spans = [];
    for (const t of toks){
      for (let i = lv.indexOf(t); i >= 0; i = lv.indexOf(t, i + t.length)) spans.push([i, i + t.length]);
    }
    if (!spans.length) return esc(v);
    spans.sort((a, b) => a[0] - b[0]);
    const merged = [spans[0]];
    for (const s of spans.slice(1)){
      const last = merged[merged.length - 1];
      if (s[0] <= last[1]) last[1] = Math.max(last[1], s[1]);
      else merged.push(s);
    }
    let out = "", at = 0;
    for (const [a, z] of merged){
      out += esc(v.slice(at, a)) + "<mark>" + esc(v.slice(a, z)) + "</mark>";
      at = z;
    }
    return out + esc(v.slice(at));
  }

  /** Anchor the box to its cell. Separate from render() because a scroll has to
   *  re-anchor without rebuilding the list - rebuilding would throw away where the
   *  reader had scrolled to, which is the very thing they were doing. */
  function place(){
    const r = cell.getBoundingClientRect();
    box.style.left = Math.max(8, Math.min(r.left, innerWidth - box.offsetWidth - 8)) + "px";
    box.style.top = (r.bottom + box.offsetHeight > innerHeight - 8
      ? Math.max(8, r.top - box.offsetHeight - 4) : r.bottom + 4) + "px";
  }

  function render(q){
    // Tokens, matched in ANY ORDER: 'phase 1 onv' should find 'ONV-101 Phase 1'. Someone
    // searching a list types the parts they remember, not the string as it was written.
    const ql = q.trim().toLowerCase();
    const toks = ql.split(/\s+/).filter(Boolean);
    let hits = items;
    if (toks.length){
      // Ranked, because token matching casts a wide net: typing '1' matches every
      // 'Phase 1' AND every 'ONV-111'. What was typed as a prefix comes first, then what
      // contains it whole, then the rest - each group in the list's own order, so the
      // ordering is stable and the thing most likely meant is at the top.
      const rank = v => {
        const lv = v.toLowerCase();
        return lv.startsWith(ql) ? 0 : lv.includes(ql) ? 1 : 2;
      };
      hits = items.filter(v => {
        const lv = v.toLowerCase();
        return toks.every(t => lv.includes(t));
      });
      hits = hits.map((v, i) => [rank(v), i, v]).sort((a, b) => a[0] - b[0] || a[1] - b[1])
                 .map(x => x[2]);
    }
    // Nothing matched is not a reason to take the chooser away - it leaves the reader
    // with no list and no way back to one. Show the whole vocabulary and say so.
    const none = toks.length > 0 && hits.length === 0;
    if (none) hits = items;
    hits = hits.slice(0, 60);
    if (!hits.length){ box.hidden = true; return; }
    // NOTHING is highlighted until an arrow key highlights it. Enter must commit what was
    // TYPED - highlighting the first row by default would make Enter silently swap in a
    // value the user never chose, which is exactly what a free-text column must not do.
    // The old code clamped idx up to 0 here; it only escaped notice because a query that
    // matched nothing used to hide the list, taking Enter out of its reach.
    idx = idx < 0 ? -1 : Math.min(idx, hits.length - 1);
    // A colour is shown as the colour, not only named (R-64): thirteen names are easier
    // to choose between when each one is a swatch as well.
    const hlCol = cell && /_highlight$/.test(cell.dataset.col || "");
    const sw = v => { const t = hlCol ? hlToken(v) : "";
      return t ? `<span class="swc" style="background:${HIGHLIGHT_FILL[t]}"></span>` : ""; };
    box.innerHTML = hits.map((v, i) =>
      `<div class="s" role="option" data-v="${att(v)}" aria-selected="${i === idx}">`
      + `${sw(v)}${none ? esc(v) : markup(v, toks)}</div>`).join("")
      + `<div class="hint">`
      + (none ? `nothing matches that \u2014 showing all ${items.length}`
              : `${hits.length}${hits.length === 60 ? "+" : ""} match${hits.length === 1 ? "" : "es"}`)
      + ` &middot; \u2191\u2193 then Enter picks one &middot; Enter alone keeps what you typed`
      + ` &middot; Esc closes</div>`;
    lodgeIn(box, cell);
    box.hidden = false;
    place();
  }

  api.open = td => {
    // Already open on this cell: leave it exactly as it is. Re-opening would reset the
    // filter and the scroll position, and this runs again whenever focus is restored
    // after a scrollbar drag.
    if (cell === td && !box.hidden) return;
    /* A figure in an assumption matrix is typed, not chosen (R-69): every other figure in
       the sheet, listed over the one being changed, is only in the way. */
    if (td.classList.contains("mx") || td.hasAttribute("data-mknew")){
      if (cell !== td) api.close();
      return;
    }
    cell = td; idx = -1;
    const row = (S.model.raw[td.dataset.sheet] || []).find(r => r.__row === +td.dataset.row);
    items = suggestionsFor(td.dataset.sheet, td.dataset.col, row);
    if (!items.length){ box.hidden = true; cell = null; return; }
    // Opening shows the WHOLE vocabulary. Filtering by the value already in the cell
    // would narrow it to that one value, which is the opposite of what a chooser is for.
    // Re-opening part-way through typing is the other case, and there the filter is the
    // point, so it is kept.
    const typed = td.textContent;
    render(typed !== (td.dataset.orig ?? "") ? typed : "");
  };
  api.close = () => { box.hidden = true; cell = null; idx = -1; api.holding = false; };
  api.owns = td => cell === td && !box.hidden;
  api.key = e => {
    if (!cell || box.hidden) return false;
    const opts = [...box.querySelectorAll(".s")];
    if (!opts.length) return false;
    if (e.key === "ArrowDown" || e.key === "ArrowUp"){
      e.preventDefault();
      idx = (idx + (e.key === "ArrowDown" ? 1 : -1) + opts.length) % opts.length;
      opts.forEach((o, i) => o.setAttribute("aria-selected", String(i === idx)));
      opts[idx].scrollIntoView({block:"nearest"});
      return true;
    }
    if (e.key === "Enter" && idx >= 0){ e.preventDefault(); choose(opts[idx].dataset.v); return true; }
    if (e.key === "Escape"){ e.preventDefault(); api.close(); return true; }
    return false;
  };
  function choose(v){
    const td = cell;
    api.close();
    td.textContent = v;
    td.blur();                                   // blur commits through the normal edit path
  }
  box.addEventListener("mousedown", e => {       // before focusout, or the cell is already gone
    // Held for the whole press, not just for a click on an option. Dragging the list's
    // OWN scrollbar takes focus off the cell, and the focusout handler would close the
    // list underneath the hand that is scrolling it. `holding` is what tells it not to.
    api.holding = true;
    const s = e.target.closest(".s");
    if (s){ e.preventDefault(); choose(s.dataset.v); api.holding = false; }
  });
  addEventListener("mouseup", () => {
    if (!api.holding) return;
    api.holding = false;
    // Put the caret back where the user left it, so the arrow keys, Enter and the
    // eventual commit-on-blur all still work after a scrollbar drag.
    if (cell && !box.hidden) cell.focus({preventScroll:true});
  });
  document.addEventListener("input", e => {
    const td = e.target.closest('td[contenteditable="true"]');
    if (td && td === cell) render(td.textContent);
  });
  /* The box is position:fixed and anchored to its cell, so a scroll that MOVES the cell
     has to be answered. Scrolling INSIDE the box is not that - it is the reader working
     through the list, and closing on it makes a list taller than the box impossible to
     reach the bottom of. So: ignore the box's own scrolling, and elsewhere re-anchor
     rather than close, closing only once the cell itself has gone off screen. */
  addEventListener("scroll", e => {
    if (!cell || box.hidden) return;
    const t = e.target;
    if (t === box || (t && t.nodeType === 1 && box.contains(t))) return;
    const r = cell.getBoundingClientRect();
    if (r.bottom < 0 || r.top > innerHeight || r.right < 0 || r.left > innerWidth) api.close();
    else place();
  }, true);
  return api;
})();

/* ---- the column filter -----------------------------------------------------
   A spreadsheet's column filter, on the six tables long enough to want one.

   Tick the values to keep. Filters on different columns narrow TOGETHER, so type =
   NewDrug CT and phase = Phase 3 leaves the rows that are both. The list offered is
   what the OTHER columns have already left reachable, which is what makes narrowing
   feel like a spreadsheet rather than like seven independent switches - A column is excluded from its OWN
   filter when its list is built, so a choice can be widened and not only narrowed; it
   is not excluded from the others, so two filters can between them leave a column with
   one value - exactly as a spreadsheet does, and cleared the same way.

   It narrows the TABLE and nothing else. The charts, the tiles and the totals are the
   plan, and a row hidden here is still in the plan; the horizon-and-filters bar at the
   top of the page is the control that changes what the figures mean. Two controls that
   both said "filter" and both changed the numbers would be one too many. */
const COLF = (() => {
  const box = el("colf");
  let sheet = null, col = null, all = [], picked = null, q = "";

  const close = () => { box.hidden = true; sheet = col = null; };

  function place(from){
    const r = from.getBoundingClientRect();
    box.hidden = false;                       // measurable only once it is laid out
    box.style.left = Math.max(8,
      Math.min(r.left - 6, innerWidth - box.offsetWidth - 8)) + "px";
    box.style.top = (r.bottom + box.offsetHeight > innerHeight - 8
      ? Math.max(8, r.top - box.offsetHeight - 4) : r.bottom + 4) + "px";
  }

  function draw(from){
    const hits = q ? all.filter(v => v.toLowerCase().includes(q.toLowerCase())) : all;
    const allOn = hits.length && hits.every(v => picked.has(v));
    box.innerHTML =
      `<div class="colf-h"><strong>${esc(col)}</strong>`
      + `<span class="tr">${picked.size} of ${all.length}</span></div>`
      + `<input class="colf-q" type="search" placeholder="Search values"
           value="${att(q)}" aria-label="Search the values">`
      + `<label class="colf-all"><input type="checkbox" ${allOn ? "checked" : ""}
           data-fall="1"><span>${q ? "All matching" : "Select all"}</span></label>`
      + `<div class="colf-list">`
      + (hits.length ? hits.map(v =>
          `<label><input type="checkbox" data-fv="${att(v)}" `
          + `${picked.has(v) ? "checked" : ""}>`
          + `<span>${v === "" ? `<i>${BLANK_LABEL}</i>` : esc(v)}</span></label>`).join("")
        : `<p class="note">Nothing matches “${esc(q)}”.</p>`)
      + `</div>`
      + `<div class="colf-f"><button class="btn tiny" data-fclearcol="1">Clear</button>`
      + `<button class="btn tiny primary" data-fapply="1">Apply</button></div>`;
    place(from);
    const s = box.querySelector(".colf-q");
    if (s){ s.focus(); s.setSelectionRange(s.value.length, s.value.length); }
  }

  /** Open the panel for one column, offering the values the other columns still allow. */
  function open(btn){
    sheet = btn.dataset.fsheet; col = btn.dataset.fcol; q = "";
    box.__from = btn;
    // Read the values off the ROWS THE RENDERER WAS GIVEN rather than off the DOM, so
    // values on rows another column's filter is hiding are still offered - otherwise a
    // filter could be narrowed but never widened again.
    const src = FTABLE[sheet];
    if (!src) return;
    const reachable = passColFilters(sheet, src.rows, src.cols, src.derived, col);
    all = [...new Set(reachable.map(r => cellText(sheet, r, col, src.derived)))]
      .sort((a, b) => a === "" ? -1 : b === "" ? 1
        : a.localeCompare(b, undefined, {numeric:true, sensitivity:"base"}));
    const on = colFilterOf(sheet, col);
    picked = new Set(on ? [...on].filter(v => all.includes(v)) : all);
    draw(btn);
  }

  function apply(){
    S.colf[sheet] = S.colf[sheet] || {};
    // Everything ticked is not a filter, it is the absence of one - and storing it as a
    // filter would freeze the column against values added later.
    if (picked.size === all.length) delete S.colf[sheet][col];
    else S.colf[sheet][col] = new Set(picked);
    if (!Object.keys(S.colf[sheet]).length) delete S.colf[sheet];
    close();
    renderKeepingTab();
  }

  document.addEventListener("mousedown", e => {
    const btn = e.target.closest(".fbtn");
    if (btn){ e.preventDefault();
              if (sheet === btn.dataset.fsheet && col === btn.dataset.fcol && !box.hidden) close();
              else open(btn);
              return; }
    const clr = e.target.closest("[data-fclear]");
    if (clr){ e.preventDefault(); delete S.colf[clr.dataset.fclear]; close(); renderKeepingTab(); return; }
    if (!box.hidden && !box.contains(e.target)) close();
  });
  box.addEventListener("change", e => {
    if (e.target.dataset.fall !== undefined){
      const hits = q ? all.filter(v => v.toLowerCase().includes(q.toLowerCase())) : all;
      if (e.target.checked) for (const v of hits) picked.add(v);
      else for (const v of hits) picked.delete(v);
      draw(box.__from);
      return;
    }
    const v = e.target.dataset.fv;
    if (v !== undefined){ e.target.checked ? picked.add(v) : picked.delete(v);
                          const h = box.querySelector(".colf-h .tr");
                          if (h) h.textContent = `${picked.size} of ${all.length}`; }
  });
  box.addEventListener("input", e => {
    if (!e.target.classList.contains("colf-q")) return;
    q = e.target.value;
    draw(box.__from);
  });
  box.addEventListener("mousedown", e => {
    if (e.target.closest("[data-fapply]")){ e.preventDefault(); apply(); }
    else if (e.target.closest("[data-fclearcol]")){
      e.preventDefault(); picked = new Set(all); apply();
    }
  });
  addEventListener("keydown", e => {
    if (e.key === "Escape" && !box.hidden){ e.preventDefault(); close(); }
  });
  /* The panel is anchored to a heading inside a scrolling table, so it has to follow
     that heading or stop pointing at it. Two things this must NOT do, both found by
     testing rather than by reading:

     - close when the panel's OWN list is scrolled. The value list scrolls at 62
       projects, and a capture-phase listener sees that scroll like any other; the first
       version shut the panel the moment you reached for a value below the fold.
     - close when the table is scrolled. Re-anchor instead, the way the calendar does,
       and give up only when the heading has actually left the window. */
  addEventListener("scroll", e => {
    if (box.hidden) return;
    const t = e.target;
    if (t === box || (t && t.nodeType === 1 && box.contains(t))) return;
    const from = box.__from;
    if (!from || !from.isConnected) return close();
    const r = from.getBoundingClientRect();
    if (r.bottom < 0 || r.top > innerHeight || r.right < 0 || r.left > innerWidth) close();
    else place(from);
  }, true);
  addEventListener("resize", () => { if (!box.hidden) close(); });
  return {close, isOpen: () => !box.hidden};
})();

/* ---- the calendar ----------------------------------------------------------
   A date column offers a month grid, and stays fully typeable while it is open.

   Both halves matter. Picking is what you want for a date you are reading off a plan
   in front of you, where "is the 14th a Tuesday" is the actual question; typing is what
   you want for the twentieth row of a set you already know, where a grid is four clicks
   to say something you could have said in eight keystrokes. So this is an OFFER laid
   beside the cell, never a gate in front of it: the caret stays in the cell, every key
   still reaches it, and what you type steers the grid rather than the other way round.

   Deliberately not <input type="date">. It would bring a native picker for nothing, and
   take the cell's own behaviour with it - one editing model for text cells and another
   for date cells, a different keyboard contract, a browser-dependent display format, and
   no way to leave a date deliberately blank the way the rest of the table does. */
const CAL = (() => {
  const box = el("cal");
  const DOW = ["Mo","Tu","We","Th","Fr","Sa","Su"];
  const MON = ["January","February","March","April","May","June",
               "July","August","September","October","November","December"];
  let cell = null, shown = null;                 // shown: the month on display
  const api = {holding:false};

  const isDate = td => (SHEET_COLS[td.dataset.sheet] || {date:[]}).date.includes(td.dataset.col);
  const readCell = () => {
    const d = parseDate((cell.textContent || "").trim());
    return d instanceof Date ? d : null;
  };
  const firstOf = d => new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1));

  /* Today, as the CLOCK ON THE USER'S COMPUTER reckons it.
   *
   * ymd() is toISOString(), which is UTC, and every other date in this application is
   * built with Date.UTC() - so for those it is exactly right. `new Date()` is not one of
   * those: it is a real instant, and putting an instant through a UTC formatter asks
   * what day it is in Greenwich, which is not the question. In Seoul at 08:30 the answer
   * came back as yesterday; in Los Angeles at 17:00 it comes back as tomorrow.
   *
   * So the local getters read the date off the user's own calendar, and Date.UTC puts it
   * back into the UTC-midnight form the rest of the application stores dates in. */
  const todayKey = () => {
    const n = new Date();
    return ymd(new Date(Date.UTC(n.getFullYear(), n.getMonth(), n.getDate())));
  };

  function place(){
    const r = cell.getBoundingClientRect();
    box.style.left = Math.max(8, Math.min(r.left, innerWidth - box.offsetWidth - 8)) + "px";
    box.style.top = (r.bottom + box.offsetHeight > innerHeight - 8
      ? Math.max(8, r.top - box.offsetHeight - 4) : r.bottom + 4) + "px";
  }

  /* `follow` is who is steering the grid.
   *
   * TRUE while the cell is: opening the panel, and every keystroke in it - type 2029 and
   * the calendar is already there, which is the behaviour the panel was built around.
   * FALSE when the user is working the arrows, because then the month on display is
   * THEIRS and the cell must not drag it back.
   *
   * Both were once true, and the arrows were unusable for it: every click re-read the
   * cell, snapped the grid to that month and stepped one from there, so a cell holding
   * 2026-09-01 went to August and stayed at August however many times it was clicked.
   * step() had a workaround - blank the cell, render, put the text back - which did not
   * work either, because step() re-read the cell before rendering. Saying which of the
   * two is steering is the whole of the fix, and it lets the cell keep its text. */
  function render(follow){
    const picked = readCell();
    if (follow && picked) shown = firstOf(picked);
    const y = shown.getUTCFullYear(), m = shown.getUTCMonth();
    const lead = (new Date(Date.UTC(y, m, 1)).getUTCDay() + 6) % 7;    // weeks start Monday
    const days = new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
    const today = todayKey();
    const cells = [];
    for (let i = 0; i < lead; i++) cells.push('<div class="d off"></div>');
    for (let n = 1; n <= days; n++){
      const k = ymd(new Date(Date.UTC(y, m, n)));
      const cls = "d" + (picked && k === ymd(picked) ? " on" : "")
                      + (k === today ? " today" : "");
      cells.push(`<button type="button" class="${cls}" data-d="${k}">${n}</button>`);
    }
    box.innerHTML =
      `<div class="calhead">`
      + `<button type="button" class="cnav" data-step="-12" title="Previous year">&#171;</button>`
      + `<button type="button" class="cnav" data-step="-1" title="Previous month">&#8249;</button>`
      + `<span class="cmon">${MON[m]} ${y}</span>`
      + `<button type="button" class="cnav" data-step="1" title="Next month">&#8250;</button>`
      + `<button type="button" class="cnav" data-step="12" title="Next year">&#187;</button>`
      + `</div>`
      + `<div class="calgrid">${DOW.map(d => `<div class="dow">${d}</div>`).join("")}`
      + cells.join("") + `</div>`
      + `<div class="calfoot">`
      + `<button type="button" class="btn tiny" data-d="${att(today)}">Today</button>`
      + `<button type="button" class="btn tiny" data-d="">Clear</button>`
      + `<span class="hint">or type it: YYYY-MM-DD</span></div>`;
    lodgeIn(box, cell);
    box.hidden = false;
    place();
  }

  api.open = td => {
    if (!isDate(td)){ if (cell !== td) api.close(); return; }
    if (cell === td && !box.hidden) return;
    cell = td;
    shown = firstOf(readCell() || parseDate(todayKey()) || new Date());
    render(true);
  };
  api.close = () => { box.hidden = true; cell = null; api.holding = false; };
  api.owns = td => cell === td && !box.hidden;
  api.key = e => {
    if (!cell || box.hidden) return false;
    if (e.key === "Escape"){ e.preventDefault(); api.close(); return true; }
    // PageUp/PageDown step the month without disturbing the caret. The arrow keys are
    // left to the text, because the caret is in the cell and moving it is what they mean
    // there - a grid that stole them would break typing to make picking prettier.
    if (e.key === "PageUp" || e.key === "PageDown"){
      e.preventDefault();
      step(e.key === "PageDown" ? 1 : -1);
      return true;
    }
    return false;
  };
  function step(n){
    shown = new Date(Date.UTC(shown.getUTCFullYear(), shown.getUTCMonth() + n, 1));
    render(false);
  }
  function choose(v){
    const td = cell;
    api.close();
    td.textContent = v;
    td.blur();                                   // blur commits through the normal path
  }
  box.addEventListener("mousedown", e => {
    api.holding = true;                          // hold focus while the panel is used
    const nav = e.target.closest(".cnav");
    if (nav){ e.preventDefault(); step(+nav.dataset.step); api.holding = false;
              if (cell) cell.focus({preventScroll:true}); return; }
    const d = e.target.closest("[data-d]");
    if (d){ e.preventDefault(); choose(d.dataset.d); api.holding = false; }
  });
  addEventListener("mouseup", () => {
    if (!api.holding) return;
    api.holding = false;
    if (cell && !box.hidden) cell.focus({preventScroll:true});
  });
  document.addEventListener("input", e => {
    const td = e.target.closest('td[contenteditable="true"]');
    if (td && td === cell) render(true);
  });
  addEventListener("scroll", e => {
    if (!cell || box.hidden) return;
    const t = e.target;
    if (t === box || (t && t.nodeType === 1 && box.contains(t))) return;
    const r = cell.getBoundingClientRect();
    if (r.bottom < 0 || r.top > innerHeight || r.right < 0 || r.left > innerWidth) api.close();
    else place();
  }, true);
  return api;
})();

/* Information pop-up. Hover shows it transiently; CLICK PINS it so it can be read
   without holding the mouse still - which is also what makes it usable on a touch
   screen and from the keyboard, where there is no hover at all. Escape or a click
   elsewhere releases the pin. */
(function(){
  const tip = el("tip");
  let pinned = null, last = {x:0, y:0};
  const place = (x, y) => {
    const pad = 14, w = tip.offsetWidth, h = tip.offsetHeight;
    let nx = x + pad, ny = y + pad;
    if (nx + w > innerWidth - 8) nx = x - w - pad;
    if (ny + h > innerHeight - 8) ny = y - h - pad;
    tip.style.left = Math.max(8, nx) + "px";
    tip.style.top = Math.max(8, ny) + "px";
  };
  /* Inside a modal dialog the pop-up has to be in the dialog - see lodgeIn(). Every chart
     in the card (R-67), and every figure in the month and team dialogs, used to hover to
     nothing. */
  const show = (html, x, y, isPin, node) => {
    lodgeIn(tip, node);
    tip.innerHTML = html + (isPin ? `<span class="tipclose">click anywhere to close</span>` : "");
    tip.hidden = false;
    tip.classList.toggle("pinned", !!isPin);
    place(x, y);
  };
  const hide = () => { if (!pinned){ tip.hidden = true; tip.classList.remove("pinned"); } };

  document.addEventListener("mouseover", e => {
    const el_ = e.target.closest("[data-tip]");
    if (!el_ || pinned) return;
    last = {x:e.clientX, y:e.clientY};
    show(el_.dataset.tip, last.x, last.y, false, el_);
  });
  document.addEventListener("mousemove", e => {
    last = {x:e.clientX, y:e.clientY};
    if (!tip.hidden && !pinned) place(last.x, last.y);
  });
  document.addEventListener("mouseout", e => { if (e.target.closest("[data-tip]")) hide(); });

  document.addEventListener("click", e => {
    const el_ = e.target.closest("[data-tip]");
    /* A control with its own job keeps it; the pop-up is explanation, not the action.
       ROLE COUNTS AS WELL AS TAG, and this listener is in the CAPTURE phase, so getting
       that list wrong does not merely pin a pop-up - it swallows the click before the
       element ever sees it. The "Off their standard" tile is a div carrying both a tip
       and role="button", and it had been silently unclickable for exactly that reason:
       everything that was supposed to happen when it was pressed never ran, and nothing
       anywhere said so. A thing that declares itself a button is a button.
       R-62: so is an issue month in Resource by project. Its pop-up still shows on
       hover, but a click opens the month and its manager review - pinning the pop-up
       instead would leave the review out of reach from the very cell it is about. */
    const isControl = e.target.closest(
      "button, a, select, input, summary, [contenteditable='true'], [role='button'], "
      + "[data-gap]");
    if (el_ && !isControl){
      e.stopPropagation();
      pinned = (pinned === el_) ? null : el_;
      if (pinned) show(el_.dataset.tip, e.clientX, e.clientY, true, el_);
      else hide();
      return;
    }
    if (pinned){ pinned = null; tip.hidden = true; tip.classList.remove("pinned"); }
  }, true);

  document.addEventListener("keydown", e => {
    if (e.key === "Escape" && pinned){ pinned = null; tip.hidden = true; tip.classList.remove("pinned"); }
  });
  // Keyboard users get the same information on focus, since they never hover.
  document.addEventListener("focusin", e => {
    const el_ = e.target.closest("[data-tip]");
    if (!el_ || pinned) return;
    const r = el_.getBoundingClientRect();
    show(el_.dataset.tip, r.left + r.width / 2, r.bottom, false, el_);
  });
  document.addEventListener("focusout", e => { if (e.target.closest("[data-tip]")) hide(); });
})();

document.addEventListener("change", e => {
  if (e.target.id === "gapfProj"){ S.gapf.proj = e.target.value; openGaps(); return; }
  if (e.target.id === "projIssue"){ S.projIssue = e.target.value; renderKeepingTab(); return; }
  if (e.target.id === "unitSel"){
    S.model.UNIT = e.target.value;
    S.model.config.capacity_unit = e.target.value;
    renderKeepingTab();
  }
});

/* ---------------------------------------------- one section, the whole screen
   See 11b_zoom.js. The state and the classes are the ui layer's; re-measuring the
   scroll regions is the shell's, because the bars are drawn here - and every region in
   the panel has just changed size by a factor of three, so the measurement is not
   optional. */
document.addEventListener("click", e => {
  const b = e.target.closest && e.target.closest("button.zoombtn");
  if (!b) return;
  const panel = b.closest(".panel[data-panel]"), sec = b.closest("section.tab");
  if (!panel || !sec) return;
  setZoom(sec.id, panel.classList.contains("zoom") ? null : panel.dataset.panel);
  cueScrollers();
  /* Keep the control under the pointer. The button is relabelled in place rather than
     replaced, so the same spot now says Close - and the second click undoes the first
     without the reader having to find anything. */
  const again = (zoomTarget() || panel).querySelector("button.zoombtn");
  if (again) again.focus();
});
/* CAPTURE, and this is the whole reason: Escape already closes the filter drop-downs and
   clears a picked series, and those handlers are bound earlier on the same element, so by
   the time a bubbling handler ran there would be nothing left to find and every Escape
   would throw away the screen as well. Running first, this can see the more local thing
   and stand aside for it - one Escape per layer, innermost first. Nothing is consumed, so
   those handlers still get their turn. */
document.addEventListener("keydown", e => {
  if (e.key !== "Escape" || !S.zoom) return;
  if (document.querySelector("details.ms[open]")) return;   // a drop-down is open
  if (document.querySelector("svg.chart.picked")) return;   // a series is picked out
  if (document.querySelector("dialog[open]")) return;       // a dialog is in front of it
  setZoom(S.zoom.tab, null);
  cueScrollers();
}, true);
/* The band wraps at narrow widths, so the height the section starts at is a function of
   the window - and the regions inside it are bounded by what is left. */
addEventListener("resize", () => {
  if (!S.zoom) return;
  fitZoom();
  cueScrollers();
});
/* The charts are drawn to the width the page has (R-67), so a window made much wider or
   narrower redraws them once it has settled - otherwise the drawing is only stretched or
   squeezed, which is exactly the oversized text that measuring was for. Not while a cell
   is being typed into: a redraw replaces the cell, and the edit with it. */
let roomTimer = 0;
addEventListener("resize", () => {
  clearTimeout(roomTimer);
  roomTimer = setTimeout(() => {
    if (!S.model || el("tabs").hidden) return;
    const was = CHART_ROOM;
    measureRoom();
    if (Math.abs(CHART_ROOM - was) < 24) return;
    const a = document.activeElement;
    if (a && a.isContentEditable) return;
    renderKeepingTab();
  }, 250);
});

el("saveBtn").onclick = saveEdits;
el("discardBtn").onclick = discardEdits;
addEventListener("beforeunload", e => {
  // REQ-IMP-08. Saved-but-not-exported changes count too: they exist only in memory.
  if (S.pending.length || S.saved){ e.preventDefault(); e.returnValue = ""; }
});
</script>
