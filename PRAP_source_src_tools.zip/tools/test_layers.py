"""The layer boundaries in src/, checked rather than asserted.

Splitting a file into folders proves nothing on its own - the folders are only worth
having if the code in them respects the line they draw. Two applications will share
core/, and the moment core/ touches a browser it stops being shareable, quietly, and
nobody notices until the desktop shell will not start.

  1. core/ never touches the DOM, the window, or a file. It decides numbers, and it
     could run in any JavaScript there is - which is what NR-PAR-01 needs of it.
  2. storage/ is small. It is the seam the desktop shell replaces, and a seam that
     grows to a thousand lines is not a seam.
  3. Every part named in the build is present, in order, with no gaps - and the file it
     builds is the one that was verified.

    python tools/test_layers.py
"""

import importlib.util
import pathlib
import re
import sys
import warnings

ROOT = pathlib.Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
sys.path.insert(0, str(ROOT / "tools"))
import build_app                                                     # noqa: E402

# Names that only exist because a browser is present. If core/ mentions one of these it
# has stopped being the shared engine and become part of the web application.
BROWSER = [
    (r"\bdocument\.", "document"),
    (r"\bwindow\.", "window"),
    (r"\blocalStorage\b", "localStorage"),
    (r"\bnavigator\.", "navigator"),
    (r"\balert\(", "alert()"),
    (r"\bconfirm\(", "confirm()"),
    (r"\bURL\.createObjectURL\b", "URL.createObjectURL"),
    (r"\baddEventListener\(", "addEventListener"),
    (r"\bel\(\"", "el(\"...\")  - the DOM lookup helper"),
]
# DOMParser, TextDecoder, Blob, DecompressionStream and TextEncoder are deliberately NOT
# on that list. They are web-platform APIs, but Node has had all of them for years, so
# core/ keeps working in the desktop shell. That is the actual test - would this run
# there - not whether the name sounds like a browser.

fails = []


def check(ok, label, detail=""):
    print(f"  {'ok  ' if ok else 'FAIL'} {label}{'   ' + detail if detail else ''}")
    if not ok:
        fails.append(label)


print("src/ — the layer boundaries")

# ---- 1. core/ is portable --------------------------------------------------
offenders = []
for p in sorted((SRC / "core").glob("*.js")):
    text = p.read_text(encoding="utf-8")
    # Comments discuss the browser constantly and legitimately; only code counts.
    code = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
    code = re.sub(r"^\s*//.*$", "", code, flags=re.M)
    for pattern, name in BROWSER:
        if re.search(pattern, code):
            offenders.append(f"{p.relative_to(SRC)} uses {name}")

check(not offenders,
      "core/ touches no DOM, no window, no dialogs — so both applications can share it",
      "; ".join(offenders[:3]) if offenders else
      f"{len(list((SRC / 'core').glob('*.js')))} files clean")

# ---- 2. the seam is small, and the implementations sit behind it -----------
web_storage = list((SRC / "storage" / "web").rglob("*.js"))
web_lines = sum(len(p.read_text(encoding="utf-8").split("\n")) for p in web_storage)
# The budget was 150 when the seam was two things - read a workbook, write a workbook.
# It is three since the change log arrived: the desktop shell appends it to a folder and
# the browser can only hand it over as a download, which is exactly the kind of
# difference this seam exists to absorb. Re-baselined at 220 rather than removed,
# because the point of the number is to catch the seam DRIFTING - a fourth
# responsibility arriving unnoticed - and a limit nobody can cross does not do that.
# Anything that pushes it past this should be asked the same question again: is this
# the seam, or is it work that belongs behind the seam?
check(web_storage and web_lines < 220,
      "the web shell's storage is small enough to be a seam — read a workbook, write "
      "a workbook, hand over the change log",
      f"{len(web_storage)} file(s), {web_lines} lines of a 220 budget")

desk_storage = list((SRC / "storage" / "desktop").rglob("*.js"))
desk_lines = sum(len(p.read_text(encoding="utf-8").split("\n")) for p in desk_storage)
check(desk_storage and desk_lines > 200,
      "and the desktop implementation behind the same seam is where the work is",
      f"{len(desk_storage)} file(s), {desk_lines} lines: "
      + ", ".join(p.stem for p in desk_storage))

# The desktop modules are Node, not a browser. If one reaches for the DOM it has been
# written in the wrong layer, and it will fail in the main process where there is none.
NODE_ONLY = [(r"\bdocument\.", "document"), (r"\bwindow\.", "window"),
             (r"\blocalStorage\b", "localStorage")]
leaks = []
for p in desk_storage + list((SRC / "shell" / "desktop").glob("*.js")):
    code = re.sub(r"/\*.*?\*/", "", p.read_text(encoding="utf-8"), flags=re.S)
    code = re.sub(r"^\s*//.*$", "", code, flags=re.M)
    for pattern, name in NODE_ONLY:
        if re.search(pattern, code):
            leaks.append(f"{p.name} uses {name}")
check(not leaks,
      "the desktop storage and shell are Node only — no DOM in the main process",
      "; ".join(leaks[:3]) if leaks else
      f"{len(desk_storage) + len(list((SRC / 'shell' / 'desktop').glob('*.js')))} files clean")

core_lines = sum(len(p.read_text(encoding="utf-8").split("\n"))
                 for p in (SRC / "core").glob("*.js"))
check(core_lines > 1000,
      "and core/ is where the weight is — the shared engine, not a stub",
      f"{core_lines} lines")

# ---- 3. the build is complete and reproduces the verified file -------------
missing = [n for n in build_app.PARTS if not (SRC / n).exists()]
check(not missing, "every part the build names exists", "; ".join(missing[:3]) or
      f"{len(build_app.PARTS)} parts")

# Every file in src/ must be reached by SOMETHING. The web build takes most of them;
# the desktop build takes the same minus the two web storage functions; and the desktop
# main process requires its own modules directly rather than being concatenated.
DESKTOP_ONLY = {"storage/desktop", "shell/desktop"}
BUILT_PAGES = {"shell/desktop/index.html"}          # emitted by build_desktop.py

# The Python shell is not concatenated - it is copied into a package tree - so its
# files are named by tools/build_python_app.py rather than by build_app.PARTS. Read
# that list rather than trusting a folder name, so a Python file nobody ships still
# shows up here as an orphan.
_pyspec = importlib.util.spec_from_file_location(
    "build_python_app", ROOT / "tools" / "build_python_app.py")
build_python_app = importlib.util.module_from_spec(_pyspec)
_pyspec.loader.exec_module(build_python_app)
PYTHON_PARTS = set(build_python_app.MODULES) | {
    "shell/python/bridge.js", "shell/python/chrome.css", "shell/python/chrome.html",
    # The difference report's SCREEN. Its engine is core/06a_diff.js and is in the web
    # build too; this file is not, because the web application is feature-frozen.
    "shell/python/importdiff.js",
    # The file window (R-63), injected ahead of the bridge that hands it the machine.
    "shell/python/filebrowser.js"}

reachable = set(build_app.PARTS) | BUILT_PAGES | PYTHON_PARTS
orphans = sorted(
    n for n in (str(p.relative_to(SRC)).replace("\\", "/")
                for p in SRC.rglob("*") if p.is_file())
    if n not in reachable and not any(n.startswith(d + "/") for d in DESKTOP_ONLY))
check(not orphans,
      "and nothing in src/ is left out of a build — an unbuilt file is a file nobody runs",
      "; ".join(orphans[:3]) if orphans else
      f"{len(build_app.PARTS)} web parts, the desktop modules, "
      f"{len(PYTHON_PARTS)} Python-shell parts")

# NR-DEP-05, and it is the requirement the whole delivery route rests on: the Python
# shell must run on a machine where nobody may install anything. One import of a
# package that is not in the standard library turns "double-click it" into "raise a
# ticket", so the imports are read rather than promised.
def code_only(text):
    """The module with its comments and string literals BLANKED OUT, in place.

    Matching DOM names against the raw text found "the browser is its window." in a
    sentence about a console window - which is prose, in a file whose whole subject is
    windows. A check a comment can fail is one people learn to word around rather than
    one they trust, so this reads the CODE.

    Blanked rather than removed, and that is the whole of the care needed here: joining
    the surviving tokens with spaces turns `window.alert` into `window . alert`, and
    joining them with nothing turns `return document.x` into `returndocument.x` - both
    of which stop the pattern matching real DOM code, which is worse than the false
    positive being fixed. Overwriting each comment and string with spaces of its own
    length leaves every other character exactly where it was.
    """
    import io
    import tokenize
    lines = text.splitlines(keepends=True)
    try:
        toks = list(tokenize.generate_tokens(io.StringIO(text).readline))
    except (tokenize.TokenError, IndentationError):
        return text                     # unparseable: fall back to the strict reading
    for tok in toks:
        if tok.type not in (tokenize.COMMENT, tokenize.STRING):
            continue
        (r0, c0), (r1, c1) = tok.start, tok.end
        for r in range(r0 - 1, r1):
            ln = lines[r]
            a = c0 if r == r0 - 1 else 0
            b = c1 if r == r1 - 1 else len(ln.rstrip("\r\n"))
            lines[r] = ln[:a] + " " * (b - a) + ln[b:]
    return "".join(lines)


STDLIB = set(getattr(sys, "stdlib_module_names", ())) | {"pmapp"}
third_party = []
for rel in sorted(build_python_app.MODULES):
    # READ THE CODE, NOT THE PROSE. This scanned the raw text and so matched a
    # docstring line beginning "from the source; ..." as an import of a package
    # called `the`. code_only() is directly below and was written for exactly this
    # ("a check a comment can fail is one people learn to word around rather than one
    # they trust") - this check simply was not using it. Wording the sentence
    # differently would have fixed the symptom and left the trap for the next person.
    src_text = code_only((SRC / rel).read_text(encoding="utf-8"))
    for m in re.finditer(r"^\s*(?:from|import)\s+([A-Za-z_][A-Za-z0-9_]*)", src_text,
                         re.M):
        mod = m.group(1)
        if mod not in STDLIB and not src_text[m.start():m.end()].lstrip().startswith(
                ("from .", "from ..")):
            third_party.append(f"{rel} imports {mod}")
check(not third_party,
      "the Python shell imports nothing but the standard library (NR-DEP-05)",
      "; ".join(third_party[:3]) if third_party else
      f"{len(build_python_app.MODULES)} modules, no pip install")



py_dom = [rel for rel in build_python_app.MODULES
          if re.search(r"\bdocument\.|\bwindow\.",
                       code_only((SRC / rel).read_text(encoding="utf-8")))]
check(not py_dom,
      "and it decides where files go, never what a number is",
      "; ".join(py_dom[:3]) if py_dom else
      f"{len(build_python_app.MODULES)} modules, no page in any of them")

built = build_app.render()
current = (ROOT / "app" / "PRAP.html").read_text(encoding="utf-8")
check(built == current,
      "the file the build produces is byte-identical to the one the 13 suites verified",
      f"{len(built):,} bytes")

layers = {n.split("/")[0] for n in build_app.PARTS}
check(layers == {"core", "ui", "storage", "shell"},
      "and the four layers the plan names are the four that exist",
      ", ".join(sorted(layers)))

# ---- every python file compiles quietly, on any python -------------------------
# A backslash that starts no known escape - "data\\shared" written as "data\shared" -
# is kept as-is by Python, so the text is right and nothing misbehaves. But it is a
# SyntaxWarning from 3.12 and an error in some later version, and the warning appears
# ON THE PREPARER'S SCREEN, in the middle of a build they are told to trust. Caught
# here rather than by whoever runs a newer Python than this: the warning is only
# raised when the file is compiled fresh, so a cached .pyc hides it too.
print("\nevery python file, compiled")
noisy = []
for q in sorted(list(SRC.rglob("*.py")) + list((ROOT / "tools").rglob("*.py"))):
    if "__pycache__" in q.parts:
        continue
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        try:
            compile(q.read_text(encoding="utf-8"), str(q), "exec")
        except SyntaxError as e:                                     # noqa: PERF203
            noisy.append(f"{q.relative_to(ROOT)}: {e}")
            continue
    for m in caught:
        if "escape sequence" in str(m.message) or issubclass(m.category, SyntaxWarning):
            noisy.append(f"{q.relative_to(ROOT)}:{m.lineno}: {m.message}")
check(not noisy,
      "NO FILE COMPILES WITH A WARNING - a build the preparer is told to trust must "
      "not print one",
      "; ".join(noisy[:3]) if noisy else
      f"{len(list(SRC.rglob('*.py'))) + len(list((ROOT / 'tools').glob('*.py')))} files, quiet")

# ---- the stylesheet's own escapes -------------------------------------------
#
# FOUND BY A READER ASKING WHAT A SYMBOL MEANT. Three rules drew a glyph through
# `content:` and every one of them had a DOUBLED backslash:
#
#     td.c.gapc.over::after{content:"\\25B2"}      drew the text  \25B2
#     td.c.gapc.short::after{content:"\\25BC"}     drew the text  \25BC
#     td.cell.clash::after{content:"\\26A0"}       drew the text  \26A0
#
# In CSS `\25B2` IS the escape; `\\25B2` is an escaped backslash followed by five
# ordinary characters. So the three marks that REQ-DSH-15 and V-33 put on a cell - the
# arrow that carries the direction when colour alone must not (D-04) - printed their own
# source code, in nine-pixel type, in the corner of every marked month. It had been
# shipping for weeks. The suite that covers those marks asked only whether `content` was
# non-empty, which `\25B2` satisfies perfectly.
#
# This is the cheap half of the cure and it needs no browser: in this stylesheet a
# doubled backslash inside content: has no legitimate use, so finding one is the finding.
# The other half is in test_gap.py and test_manual.py, which now compare the RENDERED
# character against the one that was meant.
print("\nthe stylesheet's own escapes")
css = (SRC / "ui" / "style.css").read_text(encoding="utf-8")
doubled = [ln.strip()[:70] for ln in css.splitlines() if 'content:"\\\\' in ln]
check(not doubled,
      "no content: rule escapes its own backslash - which would print the escape "
      "instead of the character it names",
      "; ".join(doubled[:3]) if doubled
      else f"{len(re.findall(chr(99) + 'ontent:', css))} content: rules, all clean")

print()
print("FAILURES: " + (", ".join(fails) if fails else "none"))
sys.exit(1 if fails else 0)
